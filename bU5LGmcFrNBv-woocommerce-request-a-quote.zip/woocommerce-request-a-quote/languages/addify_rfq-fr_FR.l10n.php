<?php
return array(
	'project-id-version'=>'Request a Quote for WooCommerce',
	'report-msgid-bugs-to'=>'',
	'pot-creation-date'=>'2020-08-07 12:20+0000',
	'po-revision-date'=>'2025-10-27 07:58+0000',
	'last-translator'=>'Admin Addiy',
	'language-team'=>'French (France)',
	'language'=>'fr_FR',
	'plural-forms'=>'nplurals=2; plural=n > 1;',
	'mime-version'=>'1.0',
	'content-type'=>'text/plain; charset=UTF-8',
	'content-transfer-encoding'=>'8bit',
	'x-generator'=>'Loco https://localise.biz/',
	'x-loco-version'=>'2.5.2; wp-5.7.1',
	'messages'=>array(
		' items in quote'=>'articles en devis',
		' View Quote'=>'Voir le devis
',
		' was placed on '=>'a été placé sur',
		'#'=>'#',
		'%s is a required field'=>'%s est un champ obligatoire!
' . "\0" . '%s sont des champs obligatoires
',
		'%s:'=>'%s:',
		'Accepted'=>'Accepté
',
		'Action'=>'Action
',
		'Add a unique name for each quote field. It is also used as meta_key to store values in database. Once publish, you will not be able to modify it.'=>'Ajoutez un nom unique pour chaque champ de devis. Il est également utilisé comme meta_key pour stocker les valeurs dans la base de données. Une fois publié, vous ne pourrez plus le modifier.
',
		'Add Comma separated file extensions. Ex. pdf,txt,jpg.'=>'Ajoutez des extensions de fichier séparées par des virgules. Ex. pdf, txt, jpg.
',
		'Add New Field'=>'Ajouter un nouveau champ
',
		'Add New Rule'=>'Ajouter une nouvelle règle
',
		'Add Option(s) for fields types ( Select, Multi-Select and Radio ).'=>'Ajoutez des options pour les types de champs (Select, Multi-Select et Radio).
',
		'Add product'=>'Ajouter un produit
',
		'Add product(s)'=>'Ajouter des produits
',
		'Add to Quote'=>'Ajouter au devis
',
		'Addify'=>'Addify
',
		'Additional Message'=>'Message supplémentaire
',
		'Admin (New Quote)'=>'Admin (nouveau devis)
',
		'Admin/Shop Manager Email Address(es)'=>'Adresse (s) e-mail de l\'administrateur / responsable de magasin
',
		'Administrator'=>'Administrateur',
		'All admin emails that are related to our module will be sent to this email address. If this email is empty then default admin email address is used. You can add more than one email addresses separated by comma (,).'=>'Tous les courriers électroniques des administrateurs qui sont liés à notre module seront envoyés à cette adresse électronique. Si cette adresse électronique est vide, l\'adresse électronique par défaut de l\'administrateur sera utilisée. Vous pouvez ajouter plusieurs adresses électroniques séparées par une virgule (,).
',
		'All Quotes'=>'Tous les devis
',
		'Allow customers to add product(s) to quote basket and ask for a quote by submitting a simple quote form.'=>'Permettez aux clients d\'ajouter des produits au panier de devis et de demander un devis en soumettant un formulaire de devis simple.
',
		'Allowed File Size'=>'Taille de fichier autorisée
',
		'Allowed File Types'=>'Types de fichiers autorisés
',
		'Alternatively, You can add quote basket by placing the short code [addify-mini-quote].'=>'Vous pouvez également ajouter un panier de devis en plaçant le code court [addify-mini-quote].
',
		'Available on backorder'=>'Disponible en réapprovisionnement
',
		'Billing Address 1'=>'Adresse de facturation 1
',
		'Billing Address 2'=>'Adresse de facturation 2',
		'Billing City'=>'Ville de facturation
',
		'Billing Company'=>'Société de facturation
',
		'Billing Email'=>'E-mail de facturation
',
		'Billing First Name'=>'Prénom de facturation
',
		'Billing Last Name'=>'Nom de famille de facturation
',
		'Billing Phone'=>'Téléphone de facturation
',
		'Billing Postcode'=>'Code postal de facturation
',
		'Button Text'=>'Texte du bouton
',
		'Cancelled'=>'Annulé
',
		'Cancelled/Rejected'=>'Annulé / Rejeté
',
		'Checkbox'=>'Case à cocher
',
		'Convert to Order'=>'Convertir en commande
',
		'Converted by'=>'Converti par
',
		'Converted to Order'=>'Converti en commande
',
		'Converted to Order(Admin)'=>'Converti en commande (Admin)
',
		'Converted to Order(Customer)'=>'Converti en commande (client)
',
		'Cost'=>'Coût
',
		'Current Status'=>'Statut actuel
',
		'Custom Button Label'=>'Étiquette de bouton personnalisée
',
		'Custom Button Link'=>'Bouton de liaison personnalisé
',
		'Custom Messages'=>'Message personnalisé',
		'Customer'=>'Client',
		'Customer Email'=>'Courriel du client
',
		'Customer Information'=>'Informations client
',
		'Customer Name'=>'Nom du client
',
		'Date'=>'Date
',
		'Declined'=>'Diminué
',
		'Declined/Products not available'=>'Refusé / Produits non disponibles
',
		'Default Value'=>'Valeur par défaut
',
		'Disable'=>'Désactiver
',
		'Disable quote basket for user roles'=>'Désactiver le panier de devis pour les rôles utilisateur
',
		'Disable quote basket for user roles. Enable for all user roles by default.'=>'Désactivez le panier de devis pour les rôles utilisateur. Activer pour tous les rôles utilisateur par défaut.
',
		'Display Name'=>'Afficher un nom
',
		'Display Order'=>'Ordre d\'affichage
',
		'Display the above label on custom button, e.g "Request a Quote".'=>'Afficher l\'étiquette ci-dessus sur le bouton personnalisé, par exemple "Demander un devis".
',
		'Display the above text when price is hidden, e.g "Price is hidden"'=>'Afficher le texte ci-dessus lorsque le prix est caché, par exemple "Le prix est caché".
',
		'Divi Builder Compatibility'=>'Compatibilité Divi Builder
',
		'Edit Field'=>'Modifier le champ
',
		'Edit Quote'=>'Ordre d\'affichage
',
		'Edit Rule'=>'Modifier la règle
',
		'Editors & Builders Settings'=>'Paramètres des éditeurs et des constructeurs
',
		'Elementor Compatibility'=>'Compatibilité Elementor',
		'Email'=>'E-mail
',
		'Email settings for each status of quote. Messages will be display before quote table in emails.'=>'Paramètres de messagerie pour chaque statut de devis. Les messages seront affichés avant le tableau des devis dans les e-mails.
',
		'Emails'=>'E-mails
',
		'Emails Settings'=>'Paramètres des e-mails
',
		'Enable'=>'Activer
',
		'Enable (Out of stock)'=>'Activer (Rupture de stock)
',
		'Enable Ajax add to Quote (Product Page)'=>'Activer l\'ajout Ajax au devis (page produit)
',
		'Enable Ajax add to Quote (Shop Page)'=>'Activer l\'ajout Ajax à la citation (page boutique)
',
		'Enable another solution if your add to cart is not replaced by plugin button.'=>'Activez une autre solution si votre ajout au panier n\'est pas remplacé par le bouton du plugin.
',
		'Enable Captcha'=>'Activer le Captcha
',
		'Enable convert to cart for customers(Quote Status: In Process, Accepted).'=>'Activer la conversion en commande pour les clients (état du devis: en cours, accepté.
',
		'Enable Convert to Order'=>'Activer la conversion en commande
',
		'Enable display of quote converted (User/Admin) in my-account quote details.'=>'Activer l\'affichage du devis converti (utilisateur / administrateur) dans les détails du devis mon compte.
',
		'Enable Divi builder compatibility.'=>'Activez la compatibilité Divi Builder.',
		'Enable Elementor compatibility'=>'Activer la compatibilité Elementor
',
		'Enable Google reCaptcha field on the Request a Quote Form.'=>'Activez le champ Google reCaptcha dans le formulaire de demande de devis.
',
		'Enable Offered Price'=>'Activer le prix offert',
		'Enable offered price and subtotal(offered price) of quote basket.'=>'Activer le prix offert et le sous-total du prix offert du panier de devis',
		'Enable Product Price'=>'Activer le prix du produit',
		'Enable product price, subtotal and total of quote basket.'=>'Activez le prix du produit, le sous-total et le total du panier de devis.
',
		'Enable Quote Converter Display'=>'Activer l\'affichage du convertisseur de devis
',
		'Enable tax calculation of quote basket items.'=>'Activer le calcul des taxes sur les articles du panier de devis.
',
		'Enable Tax Display'=>'Activer l\'affichage des taxes
',
		'Enable/Disable'=>'Activer désactiver
',
		'Enable/Disable Ajax add to quote on product page.'=>'Activer ou désactiver l\'ajout d\'ajax au devis sur la page du produit.
',
		'Enable/Disable Ajax add to quote on shop page.'=>'Activation ou désactivation de l\'ajout de la mention ajax sur la page de la boutique.
',
		'Enable/Disable Email'=>'Activer / désactiver l\'e-mail
',
		'Enable/Disable request a quote button for out of stock products. (Note: It is compatible with simple and variable products only)'=>'Activer / Désactiver le bouton de demande de devis pour les produits en rupture de stock. (Remarque: il est compatible uniquement avec les produits simples et variables
',
		'Enter number in percent to increase the offered price from standard price of product. Leave empty for standard price.'=>'Entrez le nombre en pourcentage pour augmenter le prix offert par rapport au prix standard du produit. Laissez vide pour le prix standard.
',
		'Field Attributes'=>'Attributs de champ',
		'Field Attributes and Values'=>'Attributs et valeurs de champ
',
		'Field Default Value'=>'Valeur par défaut du champ
',
		'Field for Quote Rule'=>'Champ pour la règle de devis
',
		'Field label'=>'Étiquette de champ
',
		'Field Name'=>'Nom de domaine
',
		'Field name should be unique for each field.'=>'Le nom de champ doit être unique pour chaque champ.
',
		'Field Options'=>'Options de champ
',
		'Field Placeholder'=>'Espace réservé de champ
',
		'Field Type'=>'Type de champ
',
		'Fields for Request a Quote'=>'Champs pour demander un devis
',
		'File'=>'Déposer
',
		'File size in bytes 1KB = 1000 bytes and 1MB = 1000000 bytes'=>'Taille du fichier en octets 1 KB = 1000 octets et 1 MB = 1000000 octets
',
		'First Name'=>'Prénom
',
		'General'=>'Général',
		'General Settings'=>'Paramètres généraux
',
		'Go to shop'=>'Aller à la boutique',
		'Google Captcha'=>'Google Captcha',
		'Google Captcha Settings'=>'Paramètres de Google reCaptcha
',
		'Guest'=>'Invité',
		'Heading of Email'=>'En-tête de l\'e-mail
',
		'Hide Add to Cart Button'=>'Bouton Cacher Ajouter au panier
',
		'Hide Price'=>'Cacher le prix
',
		'Hide Price Text'=>'Cacher le texte du prix
',
		'https://woocommerce.com/products/request-a-quote-plugin/'=>'https://woocommerce.com/products/request-a-quote-plugin/
',
		'Icon and Number of items'=>'Icône et nombre d\'éléments',
		'In Process'=>'En cours
',
		'Increase Offered Price'=>'Augmenter le prix offert
',
		'Invalid value posted for %s'=>'
Valeur non valide publiée pour %s',
		'Item'=>'Article
',
		'Keep Add to Cart and add a new custom button'=>'Gardez Ajouter au panier et ajoutez un nouveau bouton personnalisé
',
		'Keep Add to Cart button and add a new Quote Button'=>'Maintenir le bouton "Ajouter au panier" et ajouter un nouveau bouton "Devis
',
		'Label'=>'Label
',
		'Last Name'=>'Nom de famille
',
		'Link for custom button e.g "http://www.example.com"'=>'Lien pour le bouton personnalisé, par exemple "http://www.example.com".
',
		'Meta Key/ Field Name'=>'Meta Key / Nom du champ
',
		'Multi Select'=>'Sélection multiple
',
		'must be active for this plugin to work. Please install &amp; activate WooCommerce.'=>'doit être actif pour que ce plugin fonctionne. Veuillez installer & amp; activer WooCommerce.
',
		'New Field'=>'Nom du Champ
',
		'New Quote'=>'Nouveau devis
',
		'New Rule'=>'Nouvelle règle
',
		'Nickname'=>'Surnom
',
		'No'=>'Non
',
		'No Field found'=>'Aucun champ trouvé
',
		'No Field found in trash'=>'Aucun champ trouvé dans la corbeille
',
		'No file was uploaded by user.'=>'Aucun fichier n\'a été téléchargé par l\'utilisateur.
',
		'No item found in quote basket.'=>'Aucun article trouvé dans le panier de devis.
',
		'No products in the Quote Basket.'=>'Aucun produit dans le panier de devis.
',
		'No Quote found'=>'Aucun devis trouvé
',
		'No quote found in trash'=>'Aucune citation trouvée dans la corbeille
',
		'No quote has been made yet.'=>'Aucun devis n\'a encore été fait.
',
		'No rule found'=>'Aucune règle trouvée
',
		'No rule found in trash'=>'Aucune règle trouvée dans la corbeille
',
		'Note:'=>'Noter:',
		'Note: offered price will be display according to settings of cart. (including/excluding tax)'=>'Remarque: le prix offert sera affiché en fonction des paramètres du panier. (TTC / hors taxes)
',
		'Note: offered price will be excluding tax if products prices are excluding tax and including tax if prices are including tax.'=>'Remarque: le prix proposé sera hors taxe si les prix des produits sont hors taxe et TTC si les prix sont TTC.
',
		'Note: Tax/Vat will be calculated on quote conversion to order but it is visible to customers.'=>'Remarque: la taxe / TVA sera calculée lors de la conversion du devis en commande, mais elle est visible pour les clients.
',
		'Notify Customer'=>'Notifier le client
',
		'Number'=>'Nombre
',
		'Off. Price'=>'Désactivé. Prix
',
		'Off. Subtotal'=>'Désactivé. Total
',
		'Offered Price'=>'Prix ​​offert',
		'Offered Price Subtotal'=>'Sous-total du prix offert
',
		'Offered Subtotal'=>'Sous-total offert
',
		'Order details'=>'Détails de la commande
',
		'Page builders'=>'Créateurs de pages
',
		'Pending'=>'En attente
',
		'Pending/New Quote'=>'En attente / nouveau devis
',
		'Place Quote'=>'Déposer un devis
',
		'Please choose product options&hellip;'=>'Veuillez choisir les options du produit & hellip;
',
		'Post data should not be empty to create a quote.'=>'Les données de publication ne doivent pas être vides pour créer un devis.
',
		'Price'=>'Prix
',
		'Product'=>'Produit
',
		'Product SKU'=>'Produit SKU
',
		'Qty'=>'Qté
',
		'Quantity'=>'Quantité
',
		'Quotation #:'=>'Devis #:
',
		'Quote'=>'Devis
',
		'Quote '=>'Devis
',
		'Quote #'=>'Devis #',
		'Quote Attributes'=>'Attributs de devis
',
		'Quote Attributes Settings'=>'Paramètres des attributs de devis
',
		'Quote Basket Menu(s)'=>'Menu (s) du panier de devis
',
		'Quote Basket Style'=>'Style de panier de devis',
		'Quote Basket with Dropdown'=>'Panier de devis avec liste déroulante',
		'Quote Contents'=>'Contenu du devis
',
		'Quote Contents are empty.'=>'Le contenu du devis est vide.
',
		'Quote Date'=>'Date du devis
',
		'Quote Details'=>'Détails du devis
',
		'Quote field published'=>'Champ de devis publié
',
		'Quote field updated'=>'Champ de devis mis à jour
',
		'Quote Fields'=>'Champs de devis
',
		'Quote for User Roles'=>'Devis pour les rôles des utilisateurs
',
		'Quote ID is required to convert a quote to order.'=>'Un identifiant de devis est requis pour convertir un devis en commande.
',
		'Quote ID:'=>'Devis #:',
		'Quote is not available for selected variation.'=>'Le devis n\'est pas disponible pour la variante sélectionnée.
',
		'Quote is not available for “%s”.'=>'Le devis n\'est pas disponible pour “%s”.
',
		'Quote is not permitted for selected variation &hellip;'=>'Le devis n\'est pas autorisé pour la variante sélectionnée & hellip;
',
		'Quote is not permitted for “%s”.'=>'Le devis n\'est pas autorisé pour «% s».
',
		'Quote Number'=>'Cite un nombre
',
		'Quote published'=>'Date de publication
',
		'Quote Rule for Selected Categories'=>'Règle de devis pour certaines catégories
',
		'Quote Rule for Selected Products'=>'Règle de devis pour certains produits
',
		'Quote rule published'=>'Règle de devis publiée
',
		'Quote rule updated'=>'Règle de devis mise à jour
',
		'Quote Rules'=>'Règles de devis
',
		'Quote Status'=>'Statut du devis
',
		'Quote Submitted Successfully Message'=>'Message soumis avec succès',
		'Quote totals'=>'Citer les totaux
',
		'Quote updated'=>'Utilisateur de devis:
',
		'Quote User:'=>'Utilisateur de devis:
',
		'Quotes'=>'Devis
',
		'Radio'=>'Radio',
		'Redirect after Quote Submission'=>'Redirection après soumission du devis',
		'Redirect to any page after quote is submitted successfully.'=>'Rediriger vers n\'importe quelle page une fois le devis soumis avec succès',
		'Redirect to Quote Page'=>'Rediriger vers la page de devis',
		'Remove this item'=>'Supprimer cet article
',
		'Replace Add to Cart button with a Quote Button'=>'Remplacer le bouton "Ajouter au panier" par un bouton "Devis
',
		'Replace Add to Cart with custom button'=>'Remplacer Ajouter au panier par un bouton personnalisé
',
		'Request a Quote'=>'Demander un devis
',
		'Request a Quote Emails'=>'Demander un devis par e-mail
',
		'Request a Quote for WooCommerce'=>'Demander un devis pour WooCommerce
',
		'Request for Quote Rule'=>'Demandez un devis ',
		'Request for Quote Rules'=>'Règles de demande de devis
',
		'request-a-quote'=>'demande de devis
',
		'Required'=>'Obligatoire',
		'Return To Shop'=>'Retour à la boutique
',
		'Rule Priority'=>'Règle de Priorité
',
		'Rule Settings'=>'Paramètres des règles
',
		'Search Field'=>'Champ de recherche
',
		'Search Quote'=>'Rechercher un devis
',
		'Search Rule'=>'Règle de recherche
',
		'Secret Key'=>'Clé secrète
',
		'Select "Yes" to notify customer via email.'=>'Sélectionnez «Oui» pour informer le client par e-mail.
',
		'Select (Dropdown)'=>'Sélectionnez (liste déroulante)
',
		'Select Menu where you want to show Mini quote Basket. If there is no menu then you have to create menu in WordPress menus otherwise mini quote basket will not show.'=>'Sélectionnez le menu dans lequel vous souhaitez afficher le mini-panier de devis. S\'il n\'y a pas de menu, vous devez créer un menu dans les menus de WordPress, sinon le mini panier de devis ne s\'affichera pas.
',
		'Select to show drop down or icon with number of items in Basket.'=>'Sélectionnez pour afficher la liste déroulante ou l\'icône avec le nombre d\'articles dans le panier',
		'Settings'=>'Paramètres
',
		'Settings saved successfully.'=>'Paramètres enregistrés avec succès.
',
		'Shipping Address 1'=>'Adresse de livraison 1',
		'Shipping Address 2'=>'Adresse de livraison 2
',
		'Shipping City'=>'Ville d\'expédition
',
		'Shipping Company'=>'Transporteur
',
		'Shipping Email'=>'Email d\'expédition
',
		'Shipping First Name'=>'Prénom d\'expédition
',
		'Shipping Last Name'=>'Nom d\'expédition
',
		'Shipping Phone'=>'Téléphone d\'expédition
',
		'Shipping Postcode'=>'Code postal d\'expédition
',
		'Site Key'=>'Clé du site
',
		'Site security violated.'=>'Sécurité du site violée.
',
		'SKU'=>'SKU',
		'SKU:'=>'SKU:',
		'Solution 2'=>'Solution 2
',
		'Sorry, this product cannot be purchased.'=>'Désolé, ce produit ne peut pas être acheté.
',
		'Status'=>'Statut
',
		'Subject of Email'=>'Objet de l\'e-mail
',
		'Subtotal'=>'Total
',
		'Subtotal(offered)'=>'Sous-total (offert)
',
		'Subtotal(Standard)'=>'Sous-total (standard)
',
		'Subtotal(standard)'=>'Sous-total (standard)
',
		'Terms & Conditions'=>'termes et conditions
',
		'Text'=>'Texte
',
		'Textarea'=>'Textarea',
		'The mini quote design may not work properly for some page builders/themes. Alternatively, you can use the icon only layout or override the mini quote template by copying it to yourtheme/woocommerce/addify/rfq/quote/mini-quote-dropdown.php'=>'La conception du mini devis peut ne pas fonctionner correctement pour certains générateurs de pages / thèmes. Vous pouvez également utiliser la mise en page icône uniquement ou remplacer le modèle de mini-devis en le copiant dans votre thème / woocommerce / addify / rfq / quote / mini-quote-dropdown.php
',
		'This is Google reCaptcha secret key, you can get this from google. Without this key google reCaptcha will not work.'=>'C\'est la clé secrète de Google reCaptcha, vous pouvez l\'obtenir sur google. Sans cette clé, Google reCaptcha ne fonctionnera pas.
',
		'This is Google reCaptcha site key, you can get this from Google. Without this key Google reCaptcha will not work.'=>'C\'est la clé du site Google reCaptcha, vous pouvez l\'obtenir auprès de Google. Sans cette clé, Google reCaptcha ne fonctionnera pas.
',
		'This message will appear on quote submission page, when user submit quote.'=>'Ce message apparaîtra sur la page de soumission de devis, lorsque l\'utilisateur soumettra un devis.
',
		'This text will be shown for view quote basket button.'=>'Ce texte sera affiché pour le bouton Afficher le panier de devis',
		'Thumbnail'=>'La vignette
',
		'Total'=>'Le total
',
		'Total(standard)'=>'Total(standard)',
		'Type'=>'Taper
',
		'Update Quote'=>'Mettre à jour le devis
',
		'URL to Redirect'=>'URL à rediriger
',
		'URL to redirect after quote is submitted successfully.'=>'
URL à rediriger une fois le devis soumis avec succès',
		'User Roles'=>'Rôles des utilisateurs
',
		'Username'=>'Nom d\'utilisateur
',
		'Vat'=>'T.V.A
',
		'VAT(Standard)'=>'TVA (standard)
',
		'Vat(standard)'=>'TVA (standard)
',
		'View'=>'Voir
',
		'View Field'=>'Afficher le champ
',
		'View File'=>'Voir la fiche
',
		'View Quote'=>'Voir le devis
',
		'View Quote Basket Button Text'=>'Afficher le texte du bouton du panier de devis',
		'View Rule'=>'Voir la règle
',
		'WooCommerce Request a Quote plugin is inactive.'=>'
Le plugin WooCommerce Request a Quote est inactif.',
		'Yes'=>'Oui
',
		'You cannot add another "%s" to your quote.'=>'
Vous ne pouvez pas ajouter un autre "% s" à votre devis.',
		'Your quote is currently empty.'=>'Votre devis est actuellement vide.
',
		'Your Quote# %1$s has been converted to Order# %2$s.'=>'Votre devis# %1$s a été converti en commande# %2$s
',
		'“%1$s” has been added to your quote. %2$s'=>'“%s” a été ajouté à votre devis.',
		'“%s” has been removed from quote basket.'=>'“%s” a été retiré du panier de devis.
',
		'“%s” has not been added to your quote.'=>'“%s”',
	),
);
