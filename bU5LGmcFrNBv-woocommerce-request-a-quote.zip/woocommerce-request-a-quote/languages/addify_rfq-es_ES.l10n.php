<?php
return array(
	'project-id-version'=>'Request a Quote for WooCommerce',
	'report-msgid-bugs-to'=>'',
	'pot-creation-date'=>'2020-08-07 12:20+0000',
	'po-revision-date'=>'2025-10-27 07:58+0000',
	'last-translator'=>'Admin Addiy',
	'language-team'=>'Spanish (Spain)',
	'language'=>'es_ES',
	'plural-forms'=>'nplurals=2; plural=n != 1;',
	'mime-version'=>'1.0',
	'content-type'=>'text/plain; charset=UTF-8',
	'content-transfer-encoding'=>'8bit',
	'x-generator'=>'Loco https://localise.biz/',
	'x-loco-version'=>'2.5.2; wp-5.7.1',
	'messages'=>array(
		' items in quote'=>'artículos en cotización
',
		' View Quote'=>'Ver cotización
',
		' was placed on '=>'fue colocado en
',
		'#'=>'#',
		'%s is a required field'=>'¡es un campo obligatorio!
' . "\0" . '%s son campos obligatorios',
		'%s:'=>'%s:
',
		'Accepted'=>'Aceptado',
		'Action'=>'Acción',
		'Add a unique name for each quote field. It is also used as meta_key to store values in database. Once publish, you will not be able to modify it.'=>'Agregue un nombre único para cada campo de cotización. También se utiliza como meta_key para almacenar valores en la base de datos. Una vez publicado, no podrá modificarlo.
',
		'Add Comma separated file extensions. Ex. pdf,txt,jpg.'=>'Agregue extensiones de archivo separadas por comas. Ex. pdf, txt, jpg.
',
		'Add New Field'=>'Agregar nuevo campo
',
		'Add New Rule'=>'Agregar nueva regla',
		'Add Option(s) for fields types ( Select, Multi-Select and Radio ).'=>'Agregue Opción (es) para los tipos de campos (Selección, Selección múltiple y Radio).
',
		'Add product'=>'Añadir Producto
',
		'Add product(s)'=>'Añadir Producto
',
		'Add to Quote'=>'Agregar a cotización
',
		'Addify'=>'Addify',
		'Additional Message'=>'Mensaje adicional
',
		'Admin (New Quote)'=>'Admin (nueva cotización)
',
		'Admin/Shop Manager Email Address(es)'=>'Dirección (s) de correo electrónico del administrador / gerente de la tienda
',
		'Administrator'=>'
Administrador',
		'All admin emails that are related to our module will be sent to this email address. If this email is empty then default admin email address is used. You can add more than one email addresses separated by comma (,).'=>'Todos los correos electrónicos de administrador relacionados con nuestro módulo se enviarán a esta dirección de correo electrónico. Si este correo electrónico está vacío, se usa la dirección de correo electrónico predeterminada del administrador. Puede agregar más de una dirección de correo electrónico separadas por comas (,).',
		'All Quotes'=>'Todas las cotizaciones',
		'Allow customers to add product(s) to quote basket and ask for a quote by submitting a simple quote form.'=>'Permita que los clientes agreguen productos para cotizar la cesta y soliciten una cotización enviando un formulario de cotización simple.
',
		'Allowed File Size'=>'Tamaño de archivo permitido
',
		'Allowed File Types'=>'Allowed File Types',
		'Alternatively, You can add quote basket by placing the short code [addify-mini-quote].'=>'Alternativamente, puede agregar una cesta de cotización colocando el código corto [addify-mini-quote].
',
		'Available on backorder'=>'Disponible por pedido pendiente
',
		'Billing Address 1'=>'Dirección de facturación 1
',
		'Billing Address 2'=>'Dirección de facturación 2',
		'Billing City'=>'Dirección de facturación 1
',
		'Billing Company'=>'Compañía de facturación
',
		'Billing Email'=>'Correo Electrónico de Facturas
',
		'Billing First Name'=>'Nombre de facturación
',
		'Billing Last Name'=>'Apellido de facturación
',
		'Billing Phone'=>'Teléfono de facturación
',
		'Billing Postcode'=>'Código postal de facturación
',
		'Button Text'=>'Botón de texto
',
		'Cancelled'=>'Cancelado',
		'Cancelled/Rejected'=>'Cancelado / Rechazado
',
		'Checkbox'=>'Caja
',
		'Convert to Order'=>'Convertir a pedido
',
		'Converted by'=>'Convertido por
',
		'Converted to Order'=>'Convertido a la orden',
		'Converted to Order(Admin)'=>'Convertido a pedido (administrador)
',
		'Converted to Order(Customer)'=>'Convertido a pedido (cliente)',
		'Cost'=>'Costo
',
		'Current Status'=>'Estado actual
',
		'Custom Button Label'=>'Etiqueta de botón personalizada',
		'Custom Button Link'=>'Enlace de botón personalizado',
		'Custom Messages'=>'Mensajes personalizados
',
		'Customer'=>'Cliente
',
		'Customer Email'=>'Correo electrónico del cliente',
		'Customer Information'=>'Información al cliente
',
		'Customer Name'=>'Nombre del cliente',
		'Date'=>'Fecha',
		'Declined'=>'Rechazado',
		'Declined/Products not available'=>'Rechazado / Productos no disponibles',
		'Default Value'=>'Valor por defecto
',
		'Disable'=>'Desactivar
',
		'Disable quote basket for user roles'=>'Deshabilitar la cesta de cotizaciones para roles de usuario
',
		'Disable quote basket for user roles. Enable for all user roles by default.'=>'Deshabilite la cesta de cotizaciones para roles de usuario. Habilite para todos los roles de usuario de forma predeterminada.
',
		'Display Name'=>'Nombre para mostrar
',
		'Display Order'=>'Orden de visualización
',
		'Display the above label on custom button, e.g "Request a Quote".'=>'Muestre la etiqueta anterior en el botón personalizado, por ejemplo, "Solicitar una cotización"',
		'Display the above text when price is hidden, e.g "Price is hidden"'=>'Mostrar el texto anterior cuando el precio está oculto, por ejemplo, "El precio está oculto"',
		'Divi Builder Compatibility'=>'Habilitar la compatibilidad con Divi Builder
',
		'Edit Field'=>'Campo de correo electrónico',
		'Edit Quote'=>'Editar cotización
',
		'Edit Rule'=>'Editar regla',
		'Editors & Builders Settings'=>'Configuración de editores y constructores
',
		'Elementor Compatibility'=>'Compatibilidad Elementor
',
		'Email'=>'Correo electrónico
',
		'Email settings for each status of quote. Messages will be display before quote table in emails.'=>'Configuración de correo electrónico para cada estado de la cotización. Los mensajes se mostrarán antes de la tabla de cotizaciones en los correos electrónicos.
',
		'Emails'=>'Correos electrónicos
',
		'Emails Settings'=>'Configuración de correos electrónicos
',
		'Enable'=>'Permitir
',
		'Enable (Out of stock)'=>'Habilitar (Agotado)
',
		'Enable Ajax add to Quote (Product Page)'=>'Habilitar Ajax agregar a la cotización (página del producto)',
		'Enable Ajax add to Quote (Shop Page)'=>'Habilitar Ajax agregar a la cotización (página de la tienda)',
		'Enable another solution if your add to cart is not replaced by plugin button.'=>'Habilite otra solución si su agregar al carrito no es reemplazado por el botón de complemento
',
		'Enable Captcha'=>'Habilitar Captcha',
		'Enable convert to cart for customers(Quote Status: In Process, Accepted).'=>'Habilite la conversión a pedido para los clientes (Estado de la cotización: En proceso, Aceptado.
',
		'Enable Convert to Order'=>'Habilitar convertir a pedido
',
		'Enable display of quote converted (User/Admin) in my-account quote details.'=>'Habilitar la visualización de la cotización convertida (Usuario / Administrador) en los detalles de la cotización de mi cuenta.
',
		'Enable Divi builder compatibility.'=>'Habilite la compatibilidad con Divi Builder.
',
		'Enable Elementor compatibility'=>'Habilitar la compatibilidad con Elementor
',
		'Enable Google reCaptcha field on the Request a Quote Form.'=>'Habilite el campo Google reCaptcha en el Formulario de solicitud de presupuesto.',
		'Enable Offered Price'=>'Habilitar precio ofrecido
',
		'Enable offered price and subtotal(offered price) of quote basket.'=>'Habilitar precio ofrecido y subtotal del precio ofrecido de la cesta de cotización
',
		'Enable Product Price'=>'Habilitar precio del producto
',
		'Enable product price, subtotal and total of quote basket.'=>'Habilite el precio del producto, el subtotal y el total de la cesta de cotización.
',
		'Enable Quote Converter Display'=>'Habilitar la visualización del convertidor de cotizaciones
',
		'Enable tax calculation of quote basket items.'=>'Habilite el cálculo de impuestos de los artículos de la cesta de cotización.
',
		'Enable Tax Display'=>'Habilitar visualización de impuestos
',
		'Enable/Disable'=>'Habilitar deshabilitar
',
		'Enable/Disable Ajax add to quote on product page.'=>'Habilite o deshabilite ajax add to quote en la página del producto.',
		'Enable/Disable Ajax add to quote on shop page.'=>'Habilite o deshabilite ajax add to quote en la página de la tienda.',
		'Enable/Disable Email'=>'Activar / desactivar correo electrónico
',
		'Enable/Disable request a quote button for out of stock products. (Note: It is compatible with simple and variable products only)'=>'Activar / Desactivar solicitar un botón de cotización para productos agotados. (Nota: solo es compatible con productos simples y variables
',
		'Enter number in percent to increase the offered price from standard price of product. Leave empty for standard price.'=>'Ingrese el número en porcentaje para aumentar el precio ofrecido del precio estándar del producto. Dejar vacío para precio estándar.
',
		'Field Attributes'=>'Atributos de campo
',
		'Field Attributes and Values'=>'Atributos y valores de campo
',
		'Field Default Value'=>'Valor predeterminado del campo
',
		'Field for Quote Rule'=>'Campo para la regla de cotización
',
		'Field label'=>'Etiqueta de campo
',
		'Field Name'=>'Nombre del campo
',
		'Field name should be unique for each field.'=>'El nombre del campo debe ser único para cada campo.
',
		'Field Options'=>'Opciones de campo
',
		'Field Placeholder'=>'Marcador de posición de campo
',
		'Field Type'=>'Tipo de campo
',
		'Fields for Request a Quote'=>'Campos para solicitar una cotización
',
		'File'=>'Archivo
',
		'File size in bytes 1KB = 1000 bytes and 1MB = 1000000 bytes'=>'Tamaño del archivo en bytes 1 KB = 1000 bytes y 1 MB = 1000000 bytes
',
		'First Name'=>'Primer nombre
',
		'General'=>'General',
		'General Settings'=>'Configuración general',
		'Go to shop'=>'Ir a la tienda
',
		'Google Captcha'=>'Captcha de Google
',
		'Google Captcha Settings'=>'Configuración de Google reCaptcha',
		'Guest'=>'Invitado',
		'Heading of Email'=>'Encabezado del correo electrónico
',
		'Hide Add to Cart Button'=>'Ocultar botón Añadir al carrito',
		'Hide Price'=>'Ocultar precio',
		'Hide Price Text'=>'Ocultar texto de precio',
		'https://woocommerce.com/products/request-a-quote-plugin/'=>'https://woocommerce.com/products/request-a-quote-plugin/',
		'Icon and Number of items'=>'Icono y número de elementos
',
		'In Process'=>'En proceso
',
		'Increase Offered Price'=>'Incrementar el precio ofertado
',
		'Invalid value posted for %s'=>'Valor no válido publicado para% s
',
		'Item'=>'Artículo
',
		'Keep Add to Cart and add a new custom button'=>'Mantenga Agregar al carrito y agregue un nuevo botón personalizado',
		'Keep Add to Cart button and add a new Quote Button'=>'Mantenga el botón Agregar al carrito y agregue un nuevo botón de cotización',
		'Label'=>'Etiqueta',
		'Last Name'=>'Apellido
',
		'Link for custom button e.g "http://www.example.com"'=>'Enlace para botón personalizado, por ejemplo, "http://www.example.com"',
		'Meta Key/ Field Name'=>'Meta clave / nombre de campo
',
		'Multi Select'=>'Selección múltiple
',
		'must be active for this plugin to work. Please install &amp; activate WooCommerce.'=>'debe estar activo para que este complemento funcione. Instale & amp; activar WooCommerce.
',
		'New Field'=>'Campo de nombre',
		'New Quote'=>'Nueva cotización
',
		'New Rule'=>'Nueva regla',
		'Nickname'=>'Apodo
',
		'No'=>'No',
		'No Field found'=>'No se encontró ningún campo
',
		'No Field found in trash'=>'No se encontró ningún campo en la papelera
',
		'No file was uploaded by user.'=>'El usuario no cargó ningún archivo.
',
		'No item found in quote basket.'=>'No se ha encontrado ningún artículo en la cesta de cotización.
',
		'No products in the Quote Basket.'=>'No hay productos en la cesta de cotizaciones.',
		'No Quote found'=>'No se encontró ninguna cotización
',
		'No quote found in trash'=>'No se encontró ninguna cita en la papelera
',
		'No quote has been made yet.'=>'No se ha hecho ninguna cita todavía.',
		'No rule found'=>'No se encontró ninguna regla.',
		'No rule found in trash'=>'No se encontró ninguna regla en la papelera.',
		'Note:'=>'Nota:
',
		'Note: offered price will be display according to settings of cart. (including/excluding tax)'=>'Nota: el precio ofrecido se mostrará de acuerdo con la configuración del carrito. (impuestos incluidos / excluidos)
',
		'Note: offered price will be excluding tax if products prices are excluding tax and including tax if prices are including tax.'=>'Nota: el precio ofrecido no incluirá impuestos si los precios de los productos no incluyen impuestos e incluyen impuestos si los precios incluyen impuestos.
',
		'Note: Tax/Vat will be calculated on quote conversion to order but it is visible to customers.'=>'Nota: El impuesto / IVA se calculará sobre la conversión de cotización a pedido, pero es visible para los clientes.
',
		'Notify Customer'=>'Notificar al cliente',
		'Number'=>'Número
',
		'Off. Price'=>'Apagado. Precio
',
		'Off. Subtotal'=>'Apagado. Total parcial
',
		'Offered Price'=>'Precio ofrecido
',
		'Offered Price Subtotal'=>'Subtotal del precio ofrecido
',
		'Offered Subtotal'=>'Subtotal ofrecido
',
		'Order details'=>'Detalles del pedido
',
		'Page builders'=>'Constructores de páginas
',
		'Pending'=>'Pendiente
',
		'Pending/New Quote'=>'Pendiente / Nueva cotización
',
		'Place Quote'=>'Lugar Cotización
',
		'Please choose product options&hellip;'=>'Elija opciones de producto & hellip;
',
		'Post data should not be empty to create a quote.'=>'Los datos de la publicación no deben estar vacíos para crear una cotización.
',
		'Price'=>'Precio
',
		'Product'=>'Producto',
		'Product SKU'=>'Producto SKU',
		'Qty'=>'Cant.
',
		'Quantity'=>'Cantidad',
		'Quotation #:'=>'Cotización #:
',
		'Quote'=>'Citar	',
		'Quote '=>'Citar	',
		'Quote #'=>'Citar #',
		'Quote Attributes'=>'Atributos de cotización
',
		'Quote Attributes Settings'=>'Configuración de atributos de cotización
',
		'Quote Basket Menu(s)'=>'Menú (s) de la cesta de cotización
',
		'Quote Basket Style'=>'Estilo de cesta de cotización
',
		'Quote Basket with Dropdown'=>'Cesta de cotizaciones con menú desplegable
',
		'Quote Contents'=>'Contenido de la cotización
',
		'Quote Contents are empty.'=>'El contenido de la cotización está vacío.
',
		'Quote Date'=>'Campo de cotización publicado
',
		'Quote Details'=>'Detalles de cotización',
		'Quote field published'=>'Campo de cotización publicado
',
		'Quote field updated'=>'Se actualizó el campo de cotización
',
		'Quote Fields'=>'Campos de cotización
',
		'Quote for User Roles'=>'Presupuesto para roles de usuario',
		'Quote ID is required to convert a quote to order.'=>'Se requiere ID de cotización para convertir una cotización en pedido.
',
		'Quote ID:'=>'Citar #:',
		'Quote is not available for selected variation.'=>'La cotización no está disponible para la variación seleccionada.
',
		'Quote is not available for “%s”.'=>'La cotización no está disponible para "%s".
',
		'Quote is not permitted for selected variation &hellip;'=>'No se permiten cotizaciones para variaciones seleccionadas & hellip;
',
		'Quote is not permitted for “%s”.'=>'No se permiten cotizaciones para "%s".
',
		'Quote Number'=>'Número de cotización
',
		'Quote published'=>'Fecha de publicación',
		'Quote Rule for Selected Categories'=>'Regla de cotización para categorías seleccionadas',
		'Quote Rule for Selected Products'=>'Regla de cotización para productos seleccionados',
		'Quote rule published'=>'Regla de cotización publicada
',
		'Quote rule updated'=>'Se actualizó la regla de cotización
',
		'Quote Rules'=>'Reglas de cotización
',
		'Quote Status'=>'Estado de cotización
',
		'Quote Submitted Successfully Message'=>'Presupuesto enviado correctamente Mensaje
',
		'Quote totals'=>'Totales de cotización
',
		'Quote updated'=>'Cotización actualizada
',
		'Quote User:'=>'Citar usuario:
',
		'Quotes'=>'Citas',
		'Radio'=>'Radio
',
		'Redirect after Quote Submission'=>'Redirigir después del envío de la cotización
',
		'Redirect to any page after quote is submitted successfully.'=>'Redirigir a cualquier página después de que la cotización se haya enviado correctamente
',
		'Redirect to Quote Page'=>'Redirigir a la página de cotización
',
		'Remove this item'=>'Eliminar este elemento',
		'Replace Add to Cart button with a Quote Button'=>'Reemplace el botón Agregar al carrito con un botón de cotización',
		'Replace Add to Cart with custom button'=>'Reemplace Agregar al carrito con un botón personalizado',
		'Request a Quote'=>'Solicitar presupuesto',
		'Request a Quote Emails'=>'Solicitar una cotización correos electrónicos
',
		'Request a Quote for WooCommerce'=>'Solicite una cotización para WooCommerce',
		'Request for Quote Rule'=>'Solicitud de reglas de cotización',
		'Request for Quote Rules'=>'Solicitud de reglas de cotización',
		'request-a-quote'=>'solicitar presupuesto',
		'Required'=>'Requerido',
		'Return To Shop'=>'Volver a la tienda',
		'Rule Priority'=>'Prioridad de regla',
		'Rule Settings'=>'Configuraciones de regla',
		'Search Field'=>'Campo de búsqueda
',
		'Search Quote'=>'Buscar cotización
',
		'Search Rule'=>'Regla de búsqueda',
		'Secret Key'=>'Llave secreta',
		'Select "Yes" to notify customer via email.'=>'Seleccione "Sí" para notificar al cliente por correo electrónico.',
		'Select (Dropdown)'=>'Seleccionar (menú desplegable)
',
		'Select Menu where you want to show Mini quote Basket. If there is no menu then you have to create menu in WordPress menus otherwise mini quote basket will not show.'=>'Seleccione el menú donde desea mostrar la Mini cesta de cotizaciones. Si no hay un menú, debe crear un menú en los menús de WordPress; de lo contrario, no se mostrará la mini cesta de cotizaciones.',
		'Select to show drop down or icon with number of items in Basket.'=>'Seleccione para mostrar el menú desplegable o el icono con el número de artículos en la cesta
',
		'Settings'=>'Configuraciones',
		'Settings saved successfully.'=>'Configuraciones guardadas con éxito.',
		'Shipping Address 1'=>'Dirección de envío 1
',
		'Shipping Address 2'=>'Dirección de envío 2
',
		'Shipping City'=>'Ciudad de envío
',
		'Shipping Company'=>'Compañía de envios
',
		'Shipping Email'=>'Correo electrónico de envío
',
		'Shipping First Name'=>'Nombre de envío
',
		'Shipping Last Name'=>'Apellido de envío
',
		'Shipping Phone'=>'Teléfono de envío
',
		'Shipping Postcode'=>'Código postal de envío
',
		'Site Key'=>'Clave del sitio',
		'Site security violated.'=>'Seguridad del sitio violada.
',
		'SKU'=>'SKU',
		'SKU:'=>'SKU:',
		'Solution 2'=>'Solucion 2
',
		'Sorry, this product cannot be purchased.'=>'Lo sentimos, este producto no se puede comprar.
',
		'Status'=>'Estado
',
		'Subject of Email'=>'Asunto del correo electrónico
',
		'Subtotal'=>'Total parcial
',
		'Subtotal(offered)'=>'Subtotal (ofrecido)
',
		'Subtotal(Standard)'=>'Subtotal (estándar)
',
		'Subtotal(standard)'=>'Subtotal (estándar)
',
		'Terms & Conditions'=>'Términos y condiciones
',
		'Text'=>'Texto
',
		'Textarea'=>'Textarea
',
		'The mini quote design may not work properly for some page builders/themes. Alternatively, you can use the icon only layout or override the mini quote template by copying it to yourtheme/woocommerce/addify/rfq/quote/mini-quote-dropdown.php'=>'Es posible que el diseño de minicita no funcione correctamente para algunos creadores de páginas / temas. Alternativamente, puede usar el diseño de solo icono o anular la plantilla de mini cotización copiándola en yourtheme / woocommerce / addify / rfq / quote / mini-quote-dropdown.php
',
		'This is Google reCaptcha secret key, you can get this from google. Without this key google reCaptcha will not work.'=>'Esta es la clave secreta de Google reCaptcha, puede obtenerla de google. Sin esta clave, Google reCaptcha no funcionará.',
		'This is Google reCaptcha site key, you can get this from Google. Without this key Google reCaptcha will not work.'=>'Esta es la clave secreta de Google reCaptcha, puede obtenerla de google. Sin esta clave, Google reCaptcha no funcionará.',
		'This message will appear on quote submission page, when user submit quote.'=>'Este mensaje aparecerá en la página de envío de presupuesto, cuando el usuario envíe el presupuesto.',
		'This text will be shown for view quote basket button.'=>'Este texto se mostrará para el botón Ver cesta de cotización
',
		'Thumbnail'=>'Miniatura
',
		'Total'=>'Total
',
		'Total(standard)'=>'Total (estándar)
',
		'Type'=>'Tipo
',
		'Update Quote'=>'Actualizar cotización
',
		'URL to Redirect'=>'URL para redireccionar
',
		'URL to redirect after quote is submitted successfully.'=>'URL para redireccionar después de que la cotización se envíe correctamente
',
		'User Roles'=>'Roles del usuario
',
		'Username'=>'Nombre de usuario
',
		'Vat'=>'IVA ',
		'VAT(Standard)'=>'IVA (estándar)
',
		'Vat(standard)'=>'IVA (estándar)
',
		'View'=>'Ver',
		'View Field'=>'Ver campo
',
		'View File'=>'Ver archivo
',
		'View Quote'=>'Ver cotización',
		'View Quote Basket Button Text'=>'Ver el texto del botón de la cesta de cotización
',
		'View Rule'=>'Ver regla',
		'WooCommerce Request a Quote plugin is inactive.'=>'El complemento Solicitar una cotización de WooCommerce está inactivo.
',
		'Yes'=>'si',
		'You cannot add another "%s" to your quote.'=>'No puede agregar otro "% s" a su cotización.
',
		'Your quote is currently empty.'=>'Su cotización está actualmente vacía.',
		'Your Quote# %1$s has been converted to Order# %2$s.'=>'Su cotización #% 1 $ s se ha convertido en la orden #% 2 $ s.
',
		'“%1$s” has been added to your quote. %2$s'=>'Se ha añadido "% s" a su cotización.
',
		'“%s” has been removed from quote basket.'=>'"% S" se ha eliminado de la cesta de cotizaciones.
',
		'“%s” has not been added to your quote.'=>'"% S" no se ha agregado a su cotización.
',
	),
);
