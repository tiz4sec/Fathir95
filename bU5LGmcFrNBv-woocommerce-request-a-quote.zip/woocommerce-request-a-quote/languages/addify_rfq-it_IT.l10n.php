<?php
return array(
	'project-id-version'=>'Request a Quote for WooCommerce',
	'report-msgid-bugs-to'=>'',
	'pot-creation-date'=>'2020-08-07 12:20+0000',
	'po-revision-date'=>'2025-10-27 07:58+0000',
	'last-translator'=>'Admin Addiy',
	'language-team'=>'Italian',
	'language'=>'it_IT',
	'plural-forms'=>'nplurals=2; plural=n != 1;',
	'mime-version'=>'1.0',
	'content-type'=>'text/plain; charset=UTF-8',
	'content-transfer-encoding'=>'8bit',
	'x-generator'=>'Loco https://localise.biz/',
	'x-loco-version'=>'2.5.2; wp-5.7.1',
	'messages'=>array(
		' items in quote'=>'
articoli in preventivo',
		' View Quote'=>'Visualizza preventivo',
		' was placed on '=>'
è stato posizionato',
		'#'=>'#',
		'%s is a required field'=>'è un campo obbligatorio!' . "\0" . 'è un campo obbligatorio!',
		'%s:'=>'%s:',
		'Accepted'=>'Accettato',
		'Action'=>'Azione',
		'Add a unique name for each quote field. It is also used as meta_key to store values in database. Once publish, you will not be able to modify it.'=>'Aggiungi un nome univoco per ogni campo dell\'offerta. Viene anche utilizzato come meta_key per memorizzare i valori nel database. Una volta pubblicato, non potrai modificarlo.
',
		'Add Comma separated file extensions. Ex. pdf,txt,jpg.'=>'Aggiungi estensioni di file separate da virgole. Ex. pdf, txt, jpg.
',
		'Add New Field'=>'Aggiungi nuovo campo
',
		'Add New Rule'=>'Aggiungi nuova regola',
		'Add Option(s) for fields types ( Select, Multi-Select and Radio ).'=>'Aggiungi opzioni per i tipi di campo (Seleziona, Selezione multipla e Radio).
',
		'Add product'=>'Aggiungi prodotto
',
		'Add product(s)'=>'Aggiungi prodotto / i
',
		'Add to Quote'=>'Aggiungi a preventivo
',
		'Addify'=>'Addify',
		'Additional Message'=>'aggiuntivo',
		'Admin (New Quote)'=>'Amministratore (nuovo preventivo)
',
		'Admin/Shop Manager Email Address(es)'=>'Indirizzi email amministratore / responsabile negozio
',
		'Administrator'=>'Amministratore',
		'All admin emails that are related to our module will be sent to this email address. If this email is empty then default admin email address is used. You can add more than one email addresses separated by comma (,).'=>'Tutte le e-mail di amministrazione correlate al nostro modulo verranno inviate a questo indirizzo e-mail. Se questa e-mail è vuota, viene utilizzato l\'indirizzo e-mail amministratore predefinito. Puoi aggiungere più di un indirizzo e-mail separato da una virgola (,).',
		'All Quotes'=>'Tutte le citazioni',
		'Allow customers to add product(s) to quote basket and ask for a quote by submitting a simple quote form.'=>'Consenti ai clienti di aggiungere prodotti al carrello dei preventivi e chiedere un preventivo inviando un semplice modulo di preventivo.
',
		'Allowed File Size'=>'Dimensioni file consentite
',
		'Allowed File Types'=>'Dimensioni file consentite
',
		'Alternatively, You can add quote basket by placing the short code [addify-mini-quote].'=>'In alternativa, puoi aggiungere il carrello delle quotazioni inserendo il codice breve [addify-mini-quote].
',
		'Available on backorder'=>'Disponibile su ordinazione
',
		'Billing Address 1'=>'Indirizzo di fatturazione 1
',
		'Billing Address 2'=>'Indirizzo di fatturazione 2',
		'Billing City'=>'Città di fatturazione
',
		'Billing Company'=>'Società di fatturazione
',
		'Billing Email'=>'Email di fatturazione
',
		'Billing First Name'=>'Nome di fatturazione
',
		'Billing Last Name'=>'Cognome di fatturazione
',
		'Billing Phone'=>'Telefono di fatturazione
',
		'Billing Postcode'=>'Codice postale di fatturazione
',
		'Button Text'=>'Testo pulsante
',
		'Cancelled'=>'Annullata',
		'Cancelled/Rejected'=>'Annullato / Rifiutato
',
		'Checkbox'=>'Casella di controllo
',
		'Convert to Order'=>'Converti in ordine
',
		'Converted by'=>'Convertito da
',
		'Converted to Order'=>'Convertito in ordine
',
		'Converted to Order(Admin)'=>'Convertito in ordine (amministratore)
',
		'Converted to Order(Customer)'=>'Convertito in ordine (cliente)
',
		'Cost'=>'Costo
',
		'Current Status'=>'Stato attuale
',
		'Custom Button Label'=>'Etichetta pulsante personalizzata',
		'Custom Button Link'=>'Collegamento pulsante personalizzato',
		'Custom Messages'=>'Messaggi personalizzati',
		'Customer'=>'Cliente
',
		'Customer Email'=>'Email del cliente',
		'Customer Information'=>'informazioni per il cliente
',
		'Customer Name'=>'Nome del cliente',
		'Date'=>'Data',
		'Declined'=>'Rifiutato
',
		'Declined/Products not available'=>'Rifiutato / Prodotti non disponibili
',
		'Default Value'=>'Valore predefinito
',
		'Disable'=>'disattivare
',
		'Disable quote basket for user roles'=>'Disabilita il carrello dei preventivi per i ruoli utente
',
		'Disable quote basket for user roles. Enable for all user roles by default.'=>'Disabilita il carrello delle offerte per i ruoli utente. Abilita per tutti i ruoli utente per impostazione predefinita.
',
		'Display Name'=>'Nome da visualizzare
',
		'Display Order'=>'Ordine di visualizzazione
',
		'Display the above label on custom button, e.g "Request a Quote".'=>'Visualizza l\'etichetta sopra sul pulsante personalizzato, ad es. "Richiedi un preventivo"',
		'Display the above text when price is hidden, e.g "Price is hidden"'=>'Visualizza il testo sopra quando il prezzo è nascosto, ad es. "Il prezzo è nascosto"',
		'Divi Builder Compatibility'=>'Abilita la compatibilità con Divi Builder
',
		'Edit Field'=>'Abilita campo e-mail',
		'Edit Quote'=>'Modifica preventivo
',
		'Edit Rule'=>'Modifica regola',
		'Editors & Builders Settings'=>'Impostazioni di editor e costruttori
',
		'Elementor Compatibility'=>'
Compatibilità Elementor',
		'Email'=>'E-mail
',
		'Email settings for each status of quote. Messages will be display before quote table in emails.'=>'Impostazioni e-mail per ogni stato del preventivo. I messaggi verranno visualizzati prima della tabella delle quotazioni nelle e-mail.
',
		'Emails'=>'E-mail
',
		'Emails Settings'=>'Impostazioni e-mail
',
		'Enable'=>'Abilitare
',
		'Enable (Out of stock)'=>'Abilita (esaurito)
',
		'Enable Ajax add to Quote (Product Page)'=>'Abilita Ajax Aggiungi al preventivo (Pagina del prodotto)',
		'Enable Ajax add to Quote (Shop Page)'=>'Abilita Ajax Aggiungi al preventivo (Pagina del negozio)',
		'Enable another solution if your add to cart is not replaced by plugin button.'=>'Abilita un\'altra soluzione se il tuo Aggiungi al carrello non è sostituito dal plugin Button
',
		'Enable Captcha'=>'Abilita Captcha',
		'Enable convert to cart for customers(Quote Status: In Process, Accepted).'=>'Abilita la conversione in ordine per i clienti (Stato preventivo: In elaborazione, Accettato.
',
		'Enable Convert to Order'=>'Abilita la conversione in ordine
',
		'Enable display of quote converted (User/Admin) in my-account quote details.'=>'Abilita la visualizzazione del preventivo convertito (utente / amministratore) nei dettagli del preventivo del mio account.
',
		'Enable Divi builder compatibility.'=>'Abilita la compatibilità con Divi Builder
',
		'Enable Elementor compatibility'=>'Abilita la compatibilità con Elementor
',
		'Enable Google reCaptcha field on the Request a Quote Form.'=>'Abilita il campo Google reCaptcha nel modulo Richiedi un preventivo.',
		'Enable Offered Price'=>'Abilita prezzo offerto
',
		'Enable offered price and subtotal(offered price) of quote basket.'=>'Abilita il prezzo offerto e il totale parziale del prezzo offerto del carrello delle quotazioni
',
		'Enable Product Price'=>'Abilita prezzo prodotto
',
		'Enable product price, subtotal and total of quote basket.'=>'Abilita il prezzo del prodotto, il totale parziale e il totale del carrello preventivo.
',
		'Enable Quote Converter Display'=>'Abilita la visualizzazione del convertitore di preventivo
',
		'Enable tax calculation of quote basket items.'=>'Abilita il calcolo delle imposte degli articoli del carrello delle quotazioni.
',
		'Enable Tax Display'=>'Abilita la visualizzazione delle tasse
',
		'Enable/Disable'=>'Abilita / Disabilita
',
		'Enable/Disable Ajax add to quote on product page.'=>'Abilita o disabilita Ajax Aggiungi al preventivo nella pagina del prodotto.',
		'Enable/Disable Ajax add to quote on shop page.'=>'Abilita o disabilita Ajax Aggiungi al preventivo nella pagina del negozio.',
		'Enable/Disable Email'=>'Abilita / Disabilita e-mail
',
		'Enable/Disable request a quote button for out of stock products. (Note: It is compatible with simple and variable products only)'=>'Abilita / Disabilita il pulsante Richiedi un preventivo per i prodotti esauriti. (Nota: è compatibile solo con prodotti semplici e variabili
',
		'Enter number in percent to increase the offered price from standard price of product. Leave empty for standard price.'=>'Immettere il numero in percentuale per aumentare il prezzo offerto dal prezzo standard del prodotto. Lascia vuoto per il prezzo standard.
',
		'Field Attributes'=>'Attributi di campo
',
		'Field Attributes and Values'=>'Attributi e valori di campo
',
		'Field Default Value'=>'Valore predefinito del campo
',
		'Field for Quote Rule'=>'Campo per la regola del preventivo
',
		'Field label'=>'Etichetta del campo
',
		'Field Name'=>'Nome campo
',
		'Field name should be unique for each field.'=>'Il nome del campo deve essere univoco per ogni campo.
',
		'Field Options'=>'Opzioni di campo
',
		'Field Placeholder'=>'Segnaposto di campo
',
		'Field Type'=>'Tipo di campo
',
		'Fields for Request a Quote'=>'Campi per richiedere un preventivo
',
		'File'=>'File',
		'File size in bytes 1KB = 1000 bytes and 1MB = 1000000 bytes'=>'Dimensione del file in byte 1 KB = 1000 byte e 1 MB = 1000000 byte
',
		'First Name'=>'Nome di battesimo
',
		'General'=>'Generale
',
		'General Settings'=>'impostazioni generali',
		'Go to shop'=>'Vai a fare la spesa
',
		'Google Captcha'=>'Google Captcha
',
		'Google Captcha Settings'=>'Impostazioni di Google reCaptcha',
		'Guest'=>'ospite
',
		'Heading of Email'=>'Intestazione dell\'email
',
		'Hide Add to Cart Button'=>'Nascondi il pulsante Aggiungi al carrello',
		'Hide Price'=>'Nascondi il prezzo',
		'Hide Price Text'=>'Nascondi testo prezzo',
		'https://woocommerce.com/products/request-a-quote-plugin/'=>'https://woocommerce.com/products/request-a-quote-plugin/',
		'Icon and Number of items'=>'Icona e numero di elementi
',
		'In Process'=>'In corso
',
		'Increase Offered Price'=>'Aumenta il prezzo offerto
',
		'Invalid value posted for %s'=>'Valore non valido pubblicato per %s
',
		'Item'=>'Articolo
',
		'Keep Add to Cart and add a new custom button'=>'Mantieni Aggiungi al carrello e aggiungi un nuovo pulsante personalizzato',
		'Keep Add to Cart button and add a new Quote Button'=>'Mantieni il pulsante Aggiungi al carrello e aggiungi un nuovo pulsante Preventivo',
		'Label'=>'Etichetta',
		'Last Name'=>'Cognome
',
		'Link for custom button e.g "http://www.example.com"'=>'Link per pulsante personalizzato, ad es. "Http://www.example.com"',
		'Meta Key/ Field Name'=>'Meta chiave / nome campo
',
		'Multi Select'=>'Selezione multipla
',
		'must be active for this plugin to work. Please install &amp; activate WooCommerce.'=>'deve essere attivo affinché questo plugin funzioni. Installa & amp; attiva WooCommerce.
',
		'New Field'=>'Nome campo',
		'New Quote'=>'Nuova citazione
',
		'New Rule'=>'Nuova regola',
		'Nickname'=>'Soprannome
',
		'No'=>'No',
		'No Field found'=>'Nessun campo trovato
',
		'No Field found in trash'=>'Nessun campo trovato nel cestino
',
		'No file was uploaded by user.'=>'Nessun file è stato caricato dall\'utente.
',
		'No item found in quote basket.'=>'Nessun articolo trovato nel cestino dei preventivi.
',
		'No products in the Quote Basket.'=>'Nessun prodotto nel carrello preventivo.',
		'No Quote found'=>'Nessuna citazione trovata
',
		'No quote found in trash'=>'Nessuna citazione trovata nel cestino
',
		'No quote has been made yet.'=>'Nessun preventivo è stato ancora fatto.',
		'No rule found'=>'Nessuna regola trovata',
		'No rule found in trash'=>'Nessuna regola trovata nel cestino',
		'Note:'=>'Nota:
',
		'Note: offered price will be display according to settings of cart. (including/excluding tax)'=>'Nota: il prezzo offerto verrà visualizzato in base alle impostazioni del carrello. (tasse incluse / escluse)
',
		'Note: offered price will be excluding tax if products prices are excluding tax and including tax if prices are including tax.'=>'Nota: il prezzo offerto sarà IVA esclusa se i prezzi dei prodotti sono IVA esclusa e IVA inclusa se i prezzi sono IVA inclusa.
',
		'Note: Tax/Vat will be calculated on quote conversion to order but it is visible to customers.'=>'Nota: IVA / IVA verranno calcolate sulla conversione del preventivo in ordine, ma sono visibili ai clienti.
',
		'Notify Customer'=>'Avvisa il cliente
',
		'Number'=>'Numero
',
		'Off. Price'=>'Off. Prezzo
',
		'Off. Subtotal'=>'Off. totale parziale
',
		'Offered Price'=>'Prezzo offerto
',
		'Offered Price Subtotal'=>'Subtotale prezzo offerto
',
		'Offered Subtotal'=>'Subtotale offerto
',
		'Order details'=>'Dettagli dell\'ordine
',
		'Page builders'=>'Costruttori di pagine
',
		'Pending'=>'in attesa di
',
		'Pending/New Quote'=>'In attesa / Nuovo preventivo
',
		'Place Quote'=>'Posiziona citazione
',
		'Please choose product options&hellip;'=>'Scegli le opzioni del prodotto & hellip;
',
		'Post data should not be empty to create a quote.'=>'I dati del post non devono essere vuoti per creare un preventivo.
',
		'Price'=>'Prezzo',
		'Product'=>'Prodotto',
		'Product SKU'=>'Prodotto SKU',
		'Qty'=>'Qtà
',
		'Quantity'=>'Quantità',
		'Quotation #:'=>'Quotazione #:
',
		'Quote'=>'Preventivo',
		'Quote '=>'Preventivo',
		'Quote #'=>'Preventivo #',
		'Quote Attributes'=>'Attributi di citazione
',
		'Quote Attributes Settings'=>'Impostazioni attributi preventivo
',
		'Quote Basket Menu(s)'=>'Menu del cestino delle quotazioni
',
		'Quote Basket Style'=>'Citare lo stile del cestino
',
		'Quote Basket with Dropdown'=>'Cestino delle quotazioni con menu a discesa
',
		'Quote Contents'=>'Contenuto della citazione
',
		'Quote Contents are empty.'=>'I contenuti della citazione sono vuoti.
',
		'Quote Date'=>'Data preventivo
',
		'Quote Details'=>'Dettagli preventivo',
		'Quote field published'=>'Campo preventivo pubblicato
',
		'Quote field updated'=>'Campo preventivo aggiornato
',
		'Quote Fields'=>'Campi citazione
',
		'Quote for User Roles'=>'Preventivo per i ruoli utente',
		'Quote ID is required to convert a quote to order.'=>'L\'ID preventivo è necessario per convertire un preventivo in un ordine.
',
		'Quote ID:'=>'Preventivo #:',
		'Quote is not available for selected variation.'=>'Il preventivo non è disponibile per la variazione selezionata.
',
		'Quote is not available for “%s”.'=>'La citazione non è disponibile per "%s".
',
		'Quote is not permitted for selected variation &hellip;'=>'La citazione non è consentita per la variazione selezionata & hellip;
',
		'Quote is not permitted for “%s”.'=>'Le virgolette non sono consentite per "%s".
',
		'Quote Number'=>'Numero preventivo
',
		'Quote published'=>'Data di pubblicazione',
		'Quote Rule for Selected Categories'=>'Regola di preventivo per le categorie selezionate',
		'Quote Rule for Selected Products'=>'Regola di preventivo per prodotti selezionati',
		'Quote rule published'=>'Regola delle quotazioni pubblicata
',
		'Quote rule updated'=>'Regola delle quotazioni aggiornata
',
		'Quote Rules'=>'Regole di citazione
',
		'Quote Status'=>'Stato preventivo
',
		'Quote Submitted Successfully Message'=>'Messaggio inviato con successo
',
		'Quote totals'=>'Totali delle citazioni
',
		'Quote updated'=>'Quotazione aggiornata
',
		'Quote User:'=>'Preventivo utente:
',
		'Quotes'=>'Preventivi',
		'Radio'=>'Radio',
		'Redirect after Quote Submission'=>'Reindirizzamento dopo l\'invio del preventivo
',
		'Redirect to any page after quote is submitted successfully.'=>'Reindirizza a qualsiasi pagina dopo che il preventivo è stato inviato con successo
',
		'Redirect to Quote Page'=>'Reindirizza alla pagina del preventivo
',
		'Remove this item'=>'Rimuovi questo articolo',
		'Replace Add to Cart button with a Quote Button'=>'Sostituisci il pulsante Aggiungi al carrello con un pulsante Preventivo',
		'Replace Add to Cart with custom button'=>'Sostituisci Aggiungi al carrello con il pulsante personalizzato',
		'Request a Quote'=>'Richiedi un preventivo',
		'Request a Quote Emails'=>'Richiedi un preventivo e-mail
',
		'Request a Quote for WooCommerce'=>'Richiedi un preventivo per WooCommerce',
		'Request for Quote Rule'=>'Richiesta di regole di preventivo',
		'Request for Quote Rules'=>'Richiesta di regole di preventivo',
		'request-a-quote'=>'Richiedi un preventivo',
		'Required'=>'Necessaria',
		'Return To Shop'=>'Ritorna al negozio',
		'Rule Priority'=>'Priorità alle regole',
		'Rule Settings'=>'Impostazioni delle regole',
		'Search Field'=>'Campo di ricerca
',
		'Search Quote'=>'Cerca preventivo
',
		'Search Rule'=>'Regola di ricerca',
		'Secret Key'=>'Chiave segreta',
		'Select "Yes" to notify customer via email.'=>'Seleziona "Sì" per avvisare il cliente tramite e-mail.
',
		'Select (Dropdown)'=>'Seleziona (Dropdown)
',
		'Select Menu where you want to show Mini quote Basket. If there is no menu then you have to create menu in WordPress menus otherwise mini quote basket will not show.'=>'Selezionare il menu in cui si desidera mostrare il Mini carrello delle quotazioni. Se non è presente alcun menu, è necessario creare un menu nei menu di WordPress, altrimenti il mini cestino dei preventivi non verrà visualizzato.',
		'Select to show drop down or icon with number of items in Basket.'=>'Selezionare per mostrare il menu a discesa o l\'icona con il numero di articoli nel carrello
',
		'Settings'=>'impostazioni',
		'Settings saved successfully.'=>'Impostazioni salvate correttamente.',
		'Shipping Address 1'=>'Indirizzo di spedizione 1
',
		'Shipping Address 2'=>'Indirizzo di spedizione 2',
		'Shipping City'=>'Città di spedizione
',
		'Shipping Company'=>'Compagnia di spedizione',
		'Shipping Email'=>'Email di spedizione',
		'Shipping First Name'=>'Nome di spedizione',
		'Shipping Last Name'=>'Cognome di spedizione',
		'Shipping Phone'=>'Telefono di spedizione
',
		'Shipping Postcode'=>'Codice postale di spedizione',
		'Site Key'=>'Chiave del sito',
		'Site security violated.'=>'Sicurezza del sito violata.',
		'SKU'=>'SKU',
		'SKU:'=>'SKU',
		'Solution 2'=>'Soluzione 2',
		'Sorry, this product cannot be purchased.'=>'Spiacenti, questo prodotto non può essere acquistato.',
		'Status'=>'Stato
',
		'Subject of Email'=>'Oggetto dell\'email',
		'Subtotal'=>'totale parziale',
		'Subtotal (Standard)'=>'Totale parziale (standard)
',
		'Subtotal(offered)'=>'Subtotale (offerto)',
		'Subtotal(standard)'=>'Totale parziale (standard)',
		'Terms & Conditions'=>'Termini & Condizioni
',
		'Text'=>'Testo
',
		'Textarea'=>'Textarea',
		'The mini quote design may not work properly for some page builders/themes. Alternatively, you can use the icon only layout or override the mini quote template by copying it to yourtheme/woocommerce/addify/rfq/quote/mini-quote-dropdown.php'=>'Il design del mini preventivo potrebbe non funzionare correttamente per alcuni costruttori di pagine / temi. In alternativa, puoi utilizzare il layout solo icona o sovrascrivere il modello di mini preventivo copiandolo in yourtheme / woocommerce / addify / rfq / quote / mini-quote-dropdown.php
',
		'This is Google reCaptcha secret key, you can get this from google. Without this key google reCaptcha will not work.'=>'Questa è la chiave segreta di Google reCaptcha, puoi ottenerla da Google. Senza questa chiave, Google reCaptcha non funzionerà.',
		'This is Google reCaptcha site key, you can get this from Google. Without this key Google reCaptcha will not work.'=>'Questa è la chiave del sito di Google reCaptcha, puoi ottenerla da Google. Senza questa chiave, Google reCaptcha non funzionerà.',
		'This message will appear on quote submission page, when user submit quote.'=>'Questo messaggio verrà visualizzato nella pagina di invio del preventivo, quando l\'utente invia il preventivo.',
		'This text will be shown for view quote basket button.'=>'Questo testo verrà mostrato per il pulsante Visualizza cestino
',
		'Thumbnail'=>'Miniatura',
		'Total'=>'Totale',
		'Total(standard)'=>'Totale (standard)',
		'Type'=>'genere
',
		'Update Quote'=>'Aggiorna preventivo
',
		'URL to Redirect'=>'URL da reindirizzare
',
		'URL to redirect after quote is submitted successfully.'=>'URL da reindirizzare dopo che il preventivo è stato inviato correttamente
',
		'User Roles'=>'Ruoli utente
',
		'Username'=>'Nome utente
',
		'Vat'=>'I.V.A
',
		'Vat (Standard)'=>'Iva (standard)
',
		'Vat(standard)'=>'Iva (standard)
',
		'View'=>'Visualizza',
		'View Field'=>'Visualizza campo
',
		'View File'=>'Vedi il file
',
		'View Quote'=>'Vedi preventivo',
		'View Quote Basket Button Text'=>'Visualizza testo pulsante cestino preventivo
',
		'View Rule'=>'Visualizza regola',
		'WooCommerce Request a Quote plugin is inactive.'=>'Il plug-in Richiedi un preventivo di WooCommerce non è attivo.
',
		'Yes'=>'Sì',
		'You cannot add another "%s" to your quote.'=>'Non puoi aggiungere un altro "% s" al tuo preventivo.
',
		'Your quote is currently empty.'=>'Il tuo preventivo è attualmente vuoto.',
		'Your Quote# %1$s has been converted to Order# %2$s.'=>'Il tuo preventivo# %1$s è stato convertito nell\'ordine# %2$s.
',
		'“%1$s” has been added to your quote. %2$s'=>'"%s" è stato aggiunto al preventivo',
		'“%s” has been removed from quote basket.'=>'"% S" è stato rimosso dal carrello delle quotazioni.
',
		'“%s” has not been added to your quote.'=>'"% S" non è stato aggiunto al preventivo.
',
	),
);
