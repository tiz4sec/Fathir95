<?php
return array(
	'project-id-version'=>'Request a Quote for WooCommerce',
	'report-msgid-bugs-to'=>'',
	'pot-creation-date'=>'2020-08-07 12:20+0000',
	'po-revision-date'=>'2025-10-27 07:58+0000',
	'last-translator'=>'Admin Addiy',
	'language-team'=>'German',
	'language'=>'de_DE',
	'plural-forms'=>'nplurals=2; plural=n != 1;',
	'mime-version'=>'1.0',
	'content-type'=>'text/plain; charset=UTF-8',
	'content-transfer-encoding'=>'8bit',
	'x-generator'=>'Loco https://localise.biz/',
	'x-loco-version'=>'2.5.2; wp-5.7.1',
	'messages'=>array(
		' items in quote'=>'
Artikel im Angebot',
		' View Quote'=>'
Angebot anzeigen',
		' was placed on '=>'
wurde aufgelegt',
		'#'=>'#',
		'%s is a required field'=>'ist ein Pflichtfeld!' . "\0" . 'ist ein Pflichtfeld!',
		'%s:'=>'%s:',
		'Accepted'=>'Akzeptiert
',
		'Action'=>'Aktion',
		'Add a unique name for each quote field. It is also used as meta_key to store values in database. Once publish, you will not be able to modify it.'=>'Fügen Sie für jedes Angebotsfeld einen eindeutigen Namen hinzu. Es wird auch als meta_key verwendet, um Werte in der Datenbank zu speichern. Nach der Veröffentlichung können Sie sie nicht mehr ändern.
',
		'Add Comma separated file extensions. Ex. pdf,txt,jpg.'=>'Fügen Sie durch Kommas getrennte Dateierweiterungen hinzu. Ex. pdf, txt, jpg.
',
		'Add New Field'=>'Neues Feld hinzufügen',
		'Add New Rule'=>'Neue Regel hinzufügen',
		'Add Option(s) for fields types ( Select, Multi-Select and Radio ).'=>'Option (en) für Feldtypen hinzufügen (Auswählen, Mehrfachauswahl und Radio).
',
		'Add product'=>'Produkt hinzufügen',
		'Add product(s)'=>'Produkt (e) hinzufügen
',
		'Add to Quote'=>'Zum Angebot hinzufügen
',
		'Addify'=>'Addify',
		'Additional Message'=>'Zusätzliche Nachricht',
		'Admin (New Quote)'=>'Admin (Neues Zitat)
',
		'Admin/Shop Manager Email Address(es)'=>'E-Mail-Adresse (n) des Administrators / Shop-Managers
',
		'Administrator'=>'Administrator',
		'All admin emails that are related to our module will be sent to this email address. If this email is empty then default admin email address is used. You can add more than one email addresses separated by comma (,).'=>'Alle administrativen E-Mails, die sich auf unser Modul beziehen, werden an diese E-Mail-Adresse gesendet. Wenn diese E-Mail-Adresse leer ist, wird die Standard-E-Mail-Adresse des Administrators verwendet. Sie können mehrere durch Komma (,) getrennte E-Mail-Adressen hinzufügen.',
		'All Quotes'=>'Alle Zitate',
		'Allow customers to add product(s) to quote basket and ask for a quote by submitting a simple quote form.'=>'Ermöglichen Sie Kunden, Produkte zum Angebotskorb hinzuzufügen und ein Angebot anzufordern, indem Sie ein einfaches Angebotsformular senden.
',
		'Allowed File Size'=>'Zulässige Dateigröße
',
		'Allowed File Types'=>'Zulässige Dateitypen
',
		'Alternatively, You can add quote basket by placing the short code [addify-mini-quote].'=>'Alternativ können Sie einen Angebotskorb hinzufügen, indem Sie den Funktionscode [addify-mini-quote] eingeben.
',
		'Available on backorder'=>'Verfügbar bei Nachbestellung
',
		'Billing Address 1'=>'Rechnungsadresse 1
',
		'Billing Address 2'=>'Rechnungsadresse 2
',
		'Billing City'=>'Abrechnungsstadt
',
		'Billing Company'=>'Abrechnungsunternehmen
',
		'Billing Email'=>'Abrechnung per E-Mail
',
		'Billing First Name'=>'Abrechnung des Vornamens
',
		'Billing Last Name'=>'Abrechnung Nachname
',
		'Billing Phone'=>'Abrechnungstelefon
',
		'Billing Postcode'=>'Abrechnungs-Postleitzahl',
		'Button Text'=>'Schaltflächentext
',
		'Cancelled'=>'Abgesagt
',
		'Cancelled/Rejected'=>'Abgebrochen / Abgelehnt
',
		'Checkbox'=>'Kontrollkästchen
',
		'Convert to Order'=>'In Bestellung umwandeln
',
		'Converted by'=>'Konvertiert von
',
		'Converted to Order'=>'In Bestellung umgewandelt
',
		'Converted to Order(Admin)'=>'In Bestellung konvertiert (Admin)
',
		'Converted to Order(Customer)'=>'In Bestellung umgewandelt (Kunde)
',
		'Cost'=>'Kosten
',
		'Current Status'=>'Aktueller Status
',
		'Custom Button Label'=>'Benutzerdefinierte Tastenbeschriftung',
		'Custom Button Link'=>'Benutzerdefinierter Button-Link',
		'Custom Messages'=>'
Benutzerdefinierte Nachrichten',
		'Customer'=>'Kunde',
		'Customer Email'=>'Kunden-E-Mail',
		'Customer Information'=>'Kundeninformation
',
		'Customer Name'=>'Name des Kunden',
		'Date'=>'Datum',
		'Declined'=>'Abgelehnt',
		'Declined/Products not available'=>'Abgelehnt / Produkte nicht verfügbar',
		'Default Value'=>'Standardwert',
		'Disable'=>'Deaktivieren
',
		'Disable quote basket for user roles'=>'Deaktivieren Sie den Angebotskorb für Benutzerrollen
',
		'Disable quote basket for user roles. Enable for all user roles by default.'=>'Deaktivieren Sie den Angebotskorb für Benutzerrollen. Standardmäßig für alle Benutzerrollen aktivieren.
',
		'Display Name'=>'Anzeigename
',
		'Display Order'=>'Bestellung anzeigen
',
		'Display the above label on custom button, e.g "Request a Quote".'=>'Das obige Etikett auf der benutzerdefinierten Schaltfläche anzeigen, z.B. "Angebot anfordern".',
		'Display the above text when price is hidden, e.g "Price is hidden"'=>'Den obigen Text anzeigen, wenn der Preis versteckt ist, z.B. "Preis ist versteckt".',
		'Divi Builder Compatibility'=>'Aktivieren Sie die Divi Builder-Kompatibilität',
		'Edit Field'=>'E-Mail-Feld',
		'Edit Quote'=>'Angebot bearbeiten
',
		'Edit Rule'=>'Regel bearbeiten',
		'Editors & Builders Settings'=>'Einstellungen für Editoren und Builder
',
		'Elementor Compatibility'=>'Elementor-Kompatibilität',
		'Email'=>'Email',
		'Email settings for each status of quote. Messages will be display before quote table in emails.'=>'EmailEmail-Einstellungen für jeden Status des Angebots. Nachrichten werden vor der Angebotstabelle in E-Mails angezeigt.
',
		'Emails'=>'E-Mails
',
		'Emails Settings'=>'E-Mail-Einstellungen
',
		'Enable'=>'Aktivieren
',
		'Enable (Out of stock)'=>'Aktivieren (nicht vorrätig)
',
		'Enable Ajax add to Quote (Product Page)'=>'Aktivieren Sie Ajax add to quote (Produktseite)',
		'Enable Ajax add to Quote (Shop Page)'=>'Ajax zum Zitat hinzufügen aktivieren (Shop-Seite)',
		'Enable another solution if your add to cart is not replaced by plugin button.'=>'Aktivieren Sie eine andere Lösung, wenn Ihr Warenkorb nicht durch die Plugin-Schaltfläche ersetzt wird',
		'Enable Captcha'=>'Captcha aktivieren',
		'Enable convert to cart for customers(Quote Status: In Process, Accepted).'=>'Aktivieren Sie die Konvertierung in Bestellung für Kunden (Angebotsstatus: In Bearbeitung, Akzeptiert.
',
		'Enable Convert to Order'=>'Aktivieren Sie die Konvertierung in Bestellung
',
		'Enable display of quote converted (User/Admin) in my-account quote details.'=>'Aktivieren Sie die Anzeige des konvertierten Angebots (Benutzer / Administrator) in den Angebotsdetails meines Kontos.
',
		'Enable Divi builder compatibility.'=>'Aktivieren Sie die Divi Builder-Kompatibilität.',
		'Enable Elementor compatibility'=>'Aktivieren Sie die Elementorkompatibilität',
		'Enable Google reCaptcha field on the Request a Quote Form.'=>'Aktivieren Sie das Google reCaptcha-Feld auf dem Angebotsanfrage-Formular.',
		'Enable Offered Price'=>'Angebotenen Preis aktivieren',
		'Enable offered price and subtotal(offered price) of quote basket.'=>'Aktivieren Sie den angebotenen Preis und die Zwischensumme des angebotenen Preises des Angebotskorbs',
		'Enable Product Price'=>'Produktpreis aktivieren',
		'Enable product price, subtotal and total of quote basket.'=>'Aktivieren Sie den Produktpreis, die Zwischensumme und den Gesamtbetrag des Angebotskorbs.
',
		'Enable Quote Converter Display'=>'Aktivieren Sie die Anzeige des Angebotskonverters
',
		'Enable tax calculation of quote basket items.'=>'Aktivieren Sie die Steuerberechnung für Angebotskorbpositionen.
',
		'Enable Tax Display'=>'Steueranzeige aktivieren
',
		'Enable/Disable'=>'Aktivieren deaktivieren
',
		'Enable/Disable Ajax add to quote on product page.'=>'Aktivieren oder deaktivieren Sie Ajax add to quote auf der Produktseite.',
		'Enable/Disable Ajax add to quote on shop page.'=>'Aktivieren oder deaktivieren Sie Ajax add to quote auf der Shop-Seite.',
		'Enable/Disable Email'=>'E-Mail aktivieren / deaktivieren
',
		'Enable/Disable request a quote button for out of stock products. (Note: It is compatible with simple and variable products only)'=>'Aktivieren / Deaktivieren Sie die Schaltfläche zum Anfordern eines Angebots für nicht vorrätige Produkte. (Hinweis: Es ist nur mit einfachen und variablen Produkten kompatibel
',
		'Enter number in percent to increase the offered price from standard price of product. Leave empty for standard price.'=>'Geben Sie die Zahl in Prozent ein, um den angebotenen Preis gegenüber dem Standardpreis des Produkts zu erhöhen. Zum Standardpreis leer lassen.
',
		'Field Attributes'=>'Feldattribute
',
		'Field Attributes and Values'=>'Feldattribute und Werte
',
		'Field Default Value'=>'Feld Standardwert
',
		'Field for Quote Rule'=>'Feld für Angebotsregel
',
		'Field label'=>'Feldbezeichnung
',
		'Field Name'=>'Feldbezeichnung
',
		'Field name should be unique for each field.'=>'Der Feldname sollte für jedes Feld eindeutig sein.
',
		'Field Options'=>'Feldoptionen
',
		'Field Placeholder'=>'Feld Platzhalter
',
		'Field Type'=>'Feldtyp
',
		'Fields for Request a Quote'=>'Felder für die Angebotsanfrage
',
		'File'=>'Datei',
		'File size in bytes 1KB = 1000 bytes and 1MB = 1000000 bytes'=>'Dateigröße in Bytes 1 KB = 1000 Bytes und 1 MB = 1000000 Bytes
',
		'First Name'=>'Vorname
',
		'General'=>'Allgemeines
',
		'General Settings'=>'Allgemeine Einstellungen',
		'Go to shop'=>'Zum Laden gehen
',
		'Google Captcha'=>'Google Captcha',
		'Google Captcha Settings'=>'Google reCaptcha-Einstellungen',
		'Guest'=>'Gast
',
		'Heading of Email'=>'Überschrift der E-Mail
',
		'Hide Add to Cart Button'=>'Schaltfläche Zum Warenkorb hinzufügen ausblenden',
		'Hide Price'=>'Preis ausblenden',
		'Hide Price Text'=>'Preistext ausblenden',
		'https://woocommerce.com/products/request-a-quote-plugin/'=>'https://woocommerce.com/products/request-a-quote-plugin/',
		'Icon and Number of items'=>'Symbol und Anzahl der Elemente',
		'In Process'=>'In Bearbeitung
',
		'Increase Offered Price'=>'Erhöhen Sie den angebotenen Preis
',
		'Invalid value posted for %s'=>'Ungültiger Wert für% s',
		'Item'=>'Artikel
',
		'Keep Add to Cart and add a new custom button'=>'Behalten Sie Add to Cart bei und fügen Sie eine neue benutzerdefinierte Schaltfläche',
		'Keep Add to Cart button and add a new Quote Button'=>'Behalten Sie die Schaltfläche "In den Warenkorb" bei und fügen Sie eine neue Schaltfläche "Angebot" hinzu',
		'Label'=>'Label',
		'Last Name'=>'Nachname',
		'Link for custom button e.g "http://www.example.com"'=>'Link für benutzerdefinierte Schaltfläche z.B. "http://www.example.com".',
		'Meta Key/ Field Name'=>'Metaschlüssel / Feldname
',
		'Multi Select'=>'Mehrfachauswahl
',
		'must be active for this plugin to work. Please install &amp; activate WooCommerce.'=>'muss aktiv sein, damit dieses Plugin funktioniert. Bitte installieren Sie & amp; aktiviere WooCommerce.
',
		'New Field'=>'Name Feld',
		'New Quote'=>'Neues Zitat
',
		'New Rule'=>'Neue Regel',
		'Nickname'=>'Spitzname
',
		'No'=>'Nein',
		'No Field found'=>'Kein Feld gefunden
',
		'No Field found in trash'=>'Kein Feld im Papierkorb gefunden
',
		'No file was uploaded by user.'=>'Es wurde keine Datei vom Benutzer hochgeladen.
',
		'No item found in quote basket.'=>'Kein Artikel im Angebotskorb gefunden.
',
		'No products in the Quote Basket.'=>'Keine Produkte im Angebotskorb.',
		'No Quote found'=>'Kein Zitat gefunden
',
		'No quote found in trash'=>'Kein Zitat im Papierkorb gefunden
',
		'No quote has been made yet.'=>'Es wurde noch kein Angebot abgegeben.',
		'No rule found'=>'Keine Regel gefunden',
		'No rule found in trash'=>'Keine Regel im Papierkorb gefunden',
		'Note:'=>'Hinweis:
',
		'Note: offered price will be display according to settings of cart. (including/excluding tax)'=>'Hinweis: Der angebotene Preis wird gemäß den Einstellungen des Warenkorbs angezeigt. (einschließlich / ohne Steuern)
',
		'Note: offered price will be excluding tax if products prices are excluding tax and including tax if prices are including tax.'=>'Hinweis: Der angebotene Preis enthält keine Steuern, wenn die Produktpreise keine Steuern enthalten, und einschließlich Steuern, wenn die Preise Steuern enthalten.
',
		'Note: Tax/Vat will be calculated on quote conversion to order but it is visible to customers.'=>'Hinweis: Steuern / Mehrwertsteuer werden bei der Umrechnung des Angebots in eine Bestellung berechnet, sind jedoch für Kunden sichtbar.
',
		'Notify Customer'=>'Kunden benachrichtigen',
		'Number'=>'Nummer
',
		'Off. Price'=>'Aus. Preis
',
		'Off. Subtotal'=>'Aus. Zwischensumme
',
		'Offered Price'=>'
Angebotener Preis',
		'Offered Price Subtotal'=>'Angebotspreis Zwischensumme
',
		'Offered Subtotal'=>'Angebotene Zwischensumme',
		'Order details'=>'Bestelldetails
',
		'Page builders'=>'Seitenersteller
',
		'Pending'=>'steht aus
',
		'Pending/New Quote'=>'Ausstehendes / neues Angebot
',
		'Place Quote'=>'Zitat platzieren',
		'Please choose product options&hellip;'=>'Bitte wählen Sie Produktoptionen & hellip;
',
		'Post data should not be empty to create a quote.'=>'Post-Daten sollten nicht leer sein, um ein Angebot zu erstellen.
',
		'Price'=>'Preis
',
		'Product'=>'Produkt',
		'Product SKU'=>'Produkt-SKU',
		'Qty'=>'Menge
',
		'Quantity'=>'Anzahl',
		'Quotation #:'=>'Zitat #:
',
		'Quote'=>'Angebot',
		'Quote '=>'Angebot',
		'Quote #'=>'Angebot #',
		'Quote Attributes'=>'Attribute zitieren
',
		'Quote Attributes Settings'=>'Einstellungen für Angebotsattribute
',
		'Quote Basket Menu(s)'=>'Zitat Korb Menü (e)
',
		'Quote Basket Style'=>'Zitat Korb-Stil',
		'Quote Basket with Dropdown'=>'
Zitat Korb mit Dropdown',
		'Quote Contents'=>'Inhalt zitieren
',
		'Quote Contents are empty.'=>'Zitat Inhalt ist leer.
',
		'Quote Date'=>'Angebotsdatum',
		'Quote Details'=>'Details zum Angebot',
		'Quote field published'=>'Angebotsfeld veröffentlicht',
		'Quote field updated'=>'Angebotsfeld aktualisiert
',
		'Quote Fields'=>'Felder zitieren
',
		'Quote for User Roles'=>'Angebot für Benutzerrollen',
		'Quote ID is required to convert a quote to order.'=>'Die Angebots-ID ist erforderlich, um ein Angebot in eine Bestellung umzuwandeln.
',
		'Quote ID:'=>'Angebot #:',
		'Quote is not available for selected variation.'=>'Für ausgewählte Varianten ist kein Angebot verfügbar.
',
		'Quote is not available for “%s”.'=>'Das Angebot ist für "% s" nicht verfügbar.
',
		'Quote is not permitted for selected variation &hellip;'=>'Für ausgewählte Variationen ist kein Angebot zulässig & hellip;
',
		'Quote is not permitted for “%s”.'=>'Ein Angebot ist für "% s" nicht zulässig.
',
		'Quote Number'=>'Angebotsnummer
',
		'Quote published'=>'Datum der Veröffentlichung',
		'Quote Rule for Selected Categories'=>'Angebotsregel für ausgewählte Kategorien',
		'Quote Rule for Selected Products'=>'Angebotsregel für ausgewählte Produkte',
		'Quote rule published'=>'Angebotsregel veröffentlicht
',
		'Quote rule updated'=>'Angebotsregel aktualisiert
',
		'Quote Rules'=>'Angebotsregeln
',
		'Quote Status'=>'Angebotsstatus
',
		'Quote Submitted Successfully Message'=>'
Zitat erfolgreich übermittelt Nachricht',
		'Quote totals'=>'Angebotssummen
',
		'Quote updated'=>'Zitat aktualisiert
',
		'Quote User:'=>'Benutzer zitieren:
',
		'Quotes'=>'Zitate',
		'Radio'=>'Radio',
		'Redirect after Quote Submission'=>'Nach Angebotsabgabe umleiten',
		'Redirect to any page after quote is submitted successfully.'=>'Weiterleiten zu einer beliebigen Seite, nachdem das Angebot erfolgreich gesendet wurde',
		'Redirect to Quote Page'=>'Zur Angebotsseite umleiten',
		'Remove this item'=>'Dieses Element entfernen',
		'Replace Add to Cart button with a Quote Button'=>'Schaltfläche "In den Warenkorb legen" durch eine Schaltfläche "Zitat" ersetzen',
		'Replace Add to Cart with custom button'=>'In den Warenkorb legen durch benutzerdefinierte Schaltfläche ersetzen',
		'Request a Quote'=>'Angebot anfordern',
		'Request a Quote Emails'=>'Fordern Sie eine Angebots-E-Mail an
',
		'Request a Quote for WooCommerce'=>'Angebot für WooCommerce anfordern',
		'Request for Quote Rule'=>'Regeln für die Angebotsanfrage',
		'Request for Quote Rules'=>'Regeln für die Angebotsanfrage',
		'request-a-quote'=>'Anfrage-an-Zitat',
		'Required'=>'Erforderlich
',
		'Return To Shop'=>'Zurück zum Geschäft',
		'Rule Priority'=>'Regel Priorität',
		'Rule Settings'=>'Regel-Einstellungen',
		'Search Field'=>'Suchfeld
',
		'Search Quote'=>'Suchangebot
',
		'Search Rule'=>'Suchregel',
		'Secret Key'=>'Geheimer Schlüssel',
		'Select "Yes" to notify customer via email.'=>'Wählen Sie "Ja", um den Kunden per E-Mail zu benachrichtigen.
',
		'Select (Dropdown)'=>'Dropdown-Liste
',
		'Select Menu where you want to show Mini quote Basket. If there is no menu then you have to create menu in WordPress menus otherwise mini quote basket will not show.'=>'Wählen Sie das Menü, in dem Sie den Mini-Angebotskorb anzeigen möchten. Wenn es kein Menü gibt, müssen Sie das Menü in WordPress-Menüs erstellen, sonst wird der Mini-Angebotskorb nicht angezeigt.',
		'Select to show drop down or icon with number of items in Basket.'=>'Wählen Sie diese Option, um ein Dropdown-Menü oder ein Symbol mit der Anzahl der Elemente im Warenkorb anzuzeigen',
		'Settings'=>'Einstellungen',
		'Settings saved successfully.'=>'Einstellungen erfolgreich gespeichert.',
		'Shipping Address 1'=>'Lieferadresse 1
',
		'Shipping Address 2'=>'Lieferadresse 2',
		'Shipping City'=>'Versandstadt',
		'Shipping Company'=>'Versandunternehmen',
		'Shipping Email'=>'Versand-E-Mail',
		'Shipping First Name'=>'Versand Vorname
',
		'Shipping Last Name'=>'Versand Nachname
',
		'Shipping Phone'=>'Versand Telefon
',
		'Shipping Postcode'=>'Postleitzahl des Versands
',
		'Site Key'=>'Standort-Schlüssel',
		'Site security violated.'=>'Site-Sicherheit verletzt.
',
		'SKU'=>'SKU',
		'SKU:'=>'Artikelnummer:
',
		'Solution 2'=>'Lösung 2
',
		'Sorry, this product cannot be purchased.'=>'Dieses Produkt kann leider nicht gekauft werden.
',
		'Status'=>'Status',
		'Subject of Email'=>'Betreff der E-Mail
',
		'Subtotal'=>'Zwischensumme
',
		'Subtotal(offered)'=>'Zwischensumme (angeboten)
',
		'Subtotal(Standard)'=>'Zwischensumme (Standard)
',
		'Subtotal(standard)'=>'Zwischensumme (Standard)
',
		'Terms & Conditions'=>'Zwischensumme (Standard)
',
		'Text'=>'Text
',
		'Textarea'=>'Textbereich
',
		'The mini quote design may not work properly for some page builders/themes. Alternatively, you can use the icon only layout or override the mini quote template by copying it to yourtheme/woocommerce/addify/rfq/quote/mini-quote-dropdown.php'=>'Das Mini-Zitat-Design funktioniert bei einigen Seitenerstellern / Themen möglicherweise nicht richtig. Alternativ können Sie das Layout nur für Symbole verwenden oder die Mini-Angebotsvorlage überschreiben, indem Sie sie in Ihr Thema / woocommerce / addify / rfq / quote / mini-quote-dropdown.php kopieren
',
		'This is Google reCaptcha secret key, you can get this from google. Without this key google reCaptcha will not work.'=>'Dies ist der geheime Schlüssel von Google reCaptcha, den Sie von Google erhalten können. Ohne diesen Schlüssel wird Google reCaptcha nicht funktionieren.',
		'This is Google reCaptcha site key, you can get this from Google. Without this key Google reCaptcha will not work.'=>'Dies ist der geheime Schlüssel für Google reCaptcha, den Sie von Google erhalten können. Ohne diesen Schlüssel wird Google reCaptcha nicht funktionieren.',
		'This message will appear on quote submission page, when user submit quote.'=>'Diese Meldung erscheint auf der Seite zur Angebotsabgabe, wenn der Benutzer ein Angebot abgibt.',
		'This text will be shown for view quote basket button.'=>'Dieser Text wird für die Schaltfläche "Angebotskorb anzeigen" angezeigt',
		'Thumbnail'=>'Miniaturansicht
',
		'Total'=>'Gesamt
',
		'Total(standard)'=>'Gesamt (Standard)
',
		'Type'=>'Art
',
		'Update Quote'=>'Angebot aktualisieren
',
		'URL to Redirect'=>'URL zur Weiterleitung
',
		'URL to redirect after quote is submitted successfully.'=>'URL zur Weiterleitung nach erfolgreicher Übermittlung des Angebots',
		'User Roles'=>'Benutzerregeln
',
		'Username'=>'Nutzername
',
		'Vat'=>'Mehrwertsteuer 
',
		'VAT(Standard)'=>'Mehrwertsteuer (Standard)
',
		'Vat(standard)'=>'Mehrwertsteuer (Standard)
',
		'View'=>'Siehe',
		'View Field'=>'Ansichtsfeld
',
		'View File'=>'Datei ansehen
',
		'View Quote'=>'Zitat ansehen',
		'View Quote Basket Button Text'=>'Anzeigen des Warenkorb-Schaltflächentextes',
		'View Rule'=>'Regel anzeigen',
		'WooCommerce Request a Quote plugin is inactive.'=>'WooCommerce Request a Quote-Plugin ist inaktiv.
',
		'Yes'=>'Ja',
		'You cannot add another "%s" to your quote.'=>'Sie können Ihrem Angebot keine weiteren "% s" hinzufügen.
',
		'Your quote is currently empty.'=>'Ihr Angebot ist derzeit leer.',
		'Your Quote# %1$s has been converted to Order# %2$s.'=>'Ihr Angebot #% 1 $ s wurde in Bestellung #% 2 $ s konvertiert.
',
		'“%1$s” has been added to your quote. %2$s'=>'"%S" wurde Ihrem Angebot hinzugefügt.
',
		'“%s” has been removed from quote basket.'=>'"%S" wurde aus dem Angebotskorb entfernt.
',
		'“%s” has not been added to your quote.'=>'"%S" wurde Ihrem Angebot nicht hinzugefügt.
',
	),
);
