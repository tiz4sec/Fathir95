WooCommerce Request a Quote Plugin

Contributors: Addify
Requires at least: 6.5
Requires PHP: 7.4
Tested up to: 7.0
Stable tag: 2.9.2
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html



