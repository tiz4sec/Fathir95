<?php
/**
 * Plugin Name:       Request a Quote for WooCommerce
 * Plugin URI:        https://woocommerce.com/products/request-a-quote-plugin/
 * Description:       Allow customers to add product(s) to quote basket and ask for a quote by submitting a simple quote form.
 * Version:           2.9.2
 * Author:            Addify
 * Developed By:      Addify
 * Author URI:        https://woocommerce.com/vendor/addify/
 * Support:           https://woocommerce.com/vendor/addify/
 * License:           GNU General Public License v3.0
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.html
 * Domain Path:       /languages
 * Text Domain:       addify_rfq
 * Requires Plugins: woocommerce
 * WC requires at least: 4.0
 * WC tested up to: 10.9.4
 * Requires at least: 6.5
 * Tested up to: 7.0.0
 * Requires PHP: 8.1
 * Woo: 4872510:f687f573919bd78647d0bcacb5277b76

 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Automattic\WooCommerce\StoreApi\StoreApi;
use Automattic\WooCommerce\StoreApi\Schemas\ExtendSchema;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CartSchema;


if ( ! class_exists( 'Addify_Request_For_Quote' ) ) {

	class Addify_Request_For_Quote {

		/**
		 * Contains an array of quote items.
		 *
		 * @var array
		 */
		public $quote_fields_obj = array();

		public function __construct() {

			$this->afrfq_global_constents_vars();
			add_action( 'plugins_loaded', array( $this, 'afrfq_plugin_check' ) );
			add_action( 'wp_loaded', array( $this, 'afrfq_init' ) );
			add_action( 'init', array( $this, 'afrfq_plugin_init' ) );
			
			add_action( 'before_woocommerce_init', array( $this, 'afrfq_h_o_p_s_compatibility' ) );
			register_activation_hook( __FILE__, array( $this, 'afrfq_register_settings' ) );
			register_deactivation_hook( __FILE__, array( $this, 'afrfq_plugin_deactivate' ) );

			add_action( 'woocommerce_blocks_loaded', array( $this, 'afrfq_init_store_api' ) );

			include_once AFRFQ_PLUGIN_DIR . '/includes/post-types/class-af-r-f-q-quote-controller.php';
			include_once AFRFQ_PLUGIN_DIR . '/includes/post-types/class-af-r-f-q-rule-controller.php';
			include_once AFRFQ_PLUGIN_DIR . '/includes/class-af-r-f-q-main.php';
			include_once AFRFQ_PLUGIN_DIR . '/includes/class-af-r-f-q-quote.php';
			include_once AFRFQ_PLUGIN_DIR . '/includes/class-af-r-f-q-quote-fields.php';
			include_once AFRFQ_PLUGIN_DIR . '/includes/class-af-r-f-q-email-controller.php';
			include_once AFRFQ_PLUGIN_DIR . '/includes/class-af-r-f-q-ajax-controller.php';
			include_once AFRFQ_PLUGIN_DIR . '/includes/class-af-r-f-q-product-addon.php';
			include_once AFRFQ_PLUGIN_DIR . '/af-rfq-general-functions.php';

			if ( is_admin() ) {
				include_once AFRFQ_PLUGIN_DIR . 'admin/class-af-r-f-q-admin.php';
			} else {
				include_once AFRFQ_PLUGIN_DIR . 'front/class-af-r-f-q-front.php';
				// Load the Convert Quote to Cart handler
				include_once AFRFQ_PLUGIN_DIR . 'includes/class-af-r-f-q-convert-to-cart-handler.php';

			}
		}

		public function afrfq_plugin_init() {

			if ( defined( 'WC_PLUGIN_FILE' ) ) {
				$this->afrfq_custom_post_type();
				$this->include_compatibility_classes();
				$this->load_rest_api();
				$this->afrfq_quote_default_settings();
			}
		}

		public function afrfq_quote_default_settings() {

			if (get_option( 'afrfq_select_popup_template', null ) === null) {
				$defaults = array(
					'afrfq_select_popup_template'       => 'template_two',
					'afrfq_enable_popup_table_header_color' => 'yes',
					'afrfq_popup_table_header_color'    => '#ffffff',
					'afrfq_popup_table_header_bg_color' => '#000000',
					'afrfq_popup_active_step_button_fg_color' => '#ffffff',
					'afrfq_popup_active_step_button_bg_color' => '#0073AA',
					'afrfq_popup_previous_step_button_fg_color' => '#000000',
					'afrfq_popup_previous_step_button_bg_color' => '#ffffff',
					'afrfq_popup_next_step_button_fg_color' => '#ffffff',
					'afrfq_popup_next_step_button_bg_color' => '#0073AA',
				);
			
				foreach ( $defaults as $option_name => $default_value ) {
					if ( get_option( $option_name, null ) === null ) {
						add_option( $option_name, $default_value );
					}
				}
			}
		}
		public function afrfq_plugin_check() {

			if ( ! is_multisite() && ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ), true ) ) {
				add_action( 'admin_notices', array( $this, 'afrfq_wc_plugin_loaded' ) );
			}
		}

		public function afrfq_init_store_api() {
			include_once AFRFQ_PLUGIN_DIR . 'includes/class-af-r-f-q-extend-store-endpoint.php';

			$extend = StoreApi::container()->get( ExtendSchema::class );
			AF_R_F_Q_Extend_Store_Endpoint::init( $extend );
		}

		public function afrfq_wc_plugin_loaded() {
				// Deactivate the plugin.
				deactivate_plugins( __FILE__ );

				$afpvu_woo_check = '<div id="message" class="error">
					<p><strong>' . __( 'WooCommerce Request a Quote plugin is inactive.', 'addify_rfq' ) . '</strong> The <a href="http://wordpress.org/extend/plugins/woocommerce/">WooCommerce plugin</a> ' . __( 'must be active for this plugin to work. Please install &amp; activate WooCommerce.', 'addify_rfq' ) . ' »</p></div>';
				echo wp_kses_post( $afpvu_woo_check );
		}
		public function afrfq_h_o_p_s_compatibility() {

			if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
				\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			}
		}

		public function load_rest_api() {
			require AFRFQ_PLUGIN_DIR . 'includes/rest-api/class-server.php';
			\Addify\Request_a_Quote\RestApi\Server::instance()->init();
		}

		public function include_compatibility_classes() {

			if ( defined( 'AFB2B_PLUGIN_DIR' ) ) {
				include_once AFRFQ_PLUGIN_DIR . '/includes/class-af-r-f-q-b2b-compatibility.php';
			}

			if ( defined( 'ADDIFY_WSP_PLUGINDIR' ) ) {
				include_once AFRFQ_PLUGIN_DIR . '/includes/class-af-r-f-q-whole-sale-compatibility.php';
			}

			if (defined('ADDF_PRC_DIR')) {
				include_once AFRFQ_PLUGIN_DIR . '/includes/class-af-r-f-q-addify-price-calculator-compatibilty.php';
			}

			if (defined('AFCPB_DIR_PATH')) {
				include_once AFRFQ_PLUGIN_DIR . '/includes/class-r-f-q-addify-composite-product-builder-compatiblity.php';
			}
		}

		public function afrfq_global_constents_vars() {

			if ( ! defined( 'AFRFQ_URL' ) ) {
				define( 'AFRFQ_URL', plugin_dir_url( __FILE__ ) );
			}

			if ( ! defined( 'AFRFQ_BASENAME' ) ) {
				define( 'AFRFQ_BASENAME', plugin_basename( __FILE__ ) );
			}

			if ( ! defined( 'AFRFQ_PLUGIN_DIR' ) ) {
				define( 'AFRFQ_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
			}

			$upload_dir = wp_upload_dir();

			$upload_path = $upload_dir['basedir'] . '/addify-rfq/';

			if ( ! is_dir( $upload_path ) ) {
				mkdir( $upload_path );
			}

			$upload_url = $upload_dir['baseurl'] . '/addify-rfq/';

			define( 'AFRFQ_UPLOAD_DIR', $upload_path );
			define( 'AFRFQ_UPLOAD_URL', $upload_url );

			// a dedicated directory for temporarily store uploaded files via popup
			$upload_path = $upload_path . '/addify-rfq-temp/';

			if ( ! is_dir( $upload_path ) ) {
				mkdir( $upload_path );
			}

			$upload_url = $upload_url . '/addify-rfq-temp/';

			define( 'AFRFQ_TEMP_UPLOAD_DIR', $upload_path );
			define( 'AFRFQ_TEMP_UPLOAD_URL', $upload_url );

			// // temp file cleanup after 30 minutes
			if (!get_option('af_rfq_temp_file_cleanup') || get_option('af_rfq_temp_file_cleanup') < time() - 1800) {

				update_option('af_rfq_temp_file_cleanup', time());
				$files = glob( AFRFQ_TEMP_UPLOAD_DIR . '*' ); // Get all files in the directory

				$now = time();

				foreach ( $files as $file ) {
					if ( is_file( $file ) ) {
						if ( $now - filemtime( $file ) > 1800 ) {
							unlink( $file ); // Delete file if older than half hour
						}
					}
				}
			}
		}

		public function afrfq_init() {
			if ( function_exists( 'load_plugin_textdomain' ) ) {
				load_plugin_textdomain( 'addify_rfq', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
			}
		}

		public function afrfq_custom_post_type() {

			$labels = array(
				'name'                => esc_html__( 'Request for Quote Rules', 'addify_rfq' ),
				'singular_name'       => esc_html__( 'Request for Quote Rule', 'addify_rfq' ),
				'add_new'             => esc_html__( 'Add New Rule', 'addify_rfq' ),
				'add_new_item'        => esc_html__( 'Add New Rule', 'addify_rfq' ),
				'edit_item'           => esc_html__( 'Edit Rule', 'addify_rfq' ),
				'new_item'            => esc_html__( 'New Rule', 'addify_rfq' ),
				'view_item'           => esc_html__( 'View Rule', 'addify_rfq' ),
				'search_items'        => esc_html__( 'Search Rule', 'addify_rfq' ),
				'exclude_from_search' => true,
				'not_found'           => esc_html__( 'No rule found', 'addify_rfq' ),
				'not_found_in_trash'  => esc_html__( 'No rule found in trash', 'addify_rfq' ),
				'parent_item_colon'   => '',
				'menu_name'           => esc_html__( 'Request a Quote', 'addify_rfq' ),
				'attributes'          => esc_html__( 'Rule Priority', 'addify_rfq' ),
				'item_published'      => esc_html__( 'Quote rule published', 'addify_rfq' ),
				'item_updated'        => esc_html__( 'Quote rule updated', 'addify_rfq' ),
			);

			$args = array(
				'labels'             => $labels,
				'menu_icon'          => plugin_dir_url( __FILE__ ) . 'assets/images/small_logo_white.png',
				'public'             => false,
				'publicly_queryable' => false,
				'show_ui'            => true,
				'show_in_menu'       => 'woocommerce',
				'query_var'          => true,
				// 'rewrite'            => true,.
				'capability_type'    => 'post',
				'has_archive'        => true,
				'hierarchical'       => false,
				'menu_position'      => 30,
				'rewrite'            => array(
					'slug'       => 'addify_rfq',
					'with_front' => false,
				),
				'supports'           => array( 'title', 'page-attributes' ),
			);

			register_post_type( 'addify_rfq', $args );

			$labels = array(
				'name'                => esc_html__( 'Fields for Request a Quote', 'addify_rfq' ),
				'singular_name'       => esc_html__( 'Field for Quote Rule', 'addify_rfq' ),
				'add_new'             => esc_html__( 'Add New Field', 'addify_rfq' ),
				'add_new_item'        => esc_html__( 'Add New Field', 'addify_rfq' ),
				'edit_item'           => esc_html__( 'Edit Field', 'addify_rfq' ),
				'new_item'            => esc_html__( 'New Field', 'addify_rfq' ),
				'view_item'           => esc_html__( 'View Field', 'addify_rfq' ),
				'search_items'        => esc_html__( 'Search Field', 'addify_rfq' ),
				'exclude_from_search' => true,
				'not_found'           => esc_html__( 'No Field found', 'addify_rfq' ),
				'not_found_in_trash'  => esc_html__( 'No Field found in trash', 'addify_rfq' ),
				'parent_item_colon'   => '',
				'menu_name'           => esc_html__( 'Request a Quote', 'addify_rfq' ),
				'attributes'          => esc_html__( 'Field Attributes', 'addify_rfq' ),
				'item_published'      => esc_html__( 'Quote field published', 'addify_rfq' ),
				'item_updated'        => esc_html__( 'Quote field updated', 'addify_rfq' ),
			);

			$args = array(
				'labels'             => $labels,
				'menu_icon'          => plugin_dir_url( __FILE__ ) . 'assets/images/small_logo_white.png',
				'public'             => false,
				'publicly_queryable' => false,
				'show_ui'            => true,
				'show_in_menu'       => 'woocommerce',
				'query_var'          => true,
				// 'rewrite'            => true,.
				'capability_type'    => 'post',
				'has_archive'        => true,
				'hierarchical'       => false,
				'menu_position'      => 30,
				'rewrite'            => array(
					'slug'       => 'addify_rfq_fields',
					'with_front' => false,
				),
				'supports'           => array( 'title', 'page-attributes' ),
			);

			register_post_type( 'addify_rfq_fields', $args );

			$labels = array(
				'name'                => esc_html__( 'Quotes', 'addify_rfq' ),
				'singular_name'       => esc_html__( 'Quote', 'addify_rfq' ),
				'add_new'             => esc_html__( 'New Quote', 'addify_rfq' ),
				'add_new_item'        => esc_html__( 'New Quote', 'addify_rfq' ),
				'edit_item'           => esc_html__( 'Edit Quote', 'addify_rfq' ),
				'new_item'            => esc_html__( 'New Quote', 'addify_rfq' ),
				'view_item'           => esc_html__( 'View Quote', 'addify_rfq' ),
				'search_items'        => esc_html__( 'Search Quote', 'addify_rfq' ),
				'exclude_from_search' => true,
				'not_found'           => esc_html__( 'No Quote found', 'addify_rfq' ),
				'not_found_in_trash'  => esc_html__( 'No quote found in trash', 'addify_rfq' ),
				'parent_item_colon'   => '',
				'menu_name'           => esc_html__( 'Request a Quote', 'addify_rfq' ),
				'item_published'      => esc_html__( 'Quote published', 'addify_rfq' ),
				'item_updated'        => esc_html__( 'Quote updated', 'addify_rfq' ),
			);

			$args = array(
				'labels'             => $labels,
				'menu_icon'          => plugin_dir_url( __FILE__ ) . 'assets/images/small_logo_white.png',
				'public'             => false,
				'publicly_queryable' => false,
				'show_ui'            => true,
				'show_in_menu'       => 'woocommerce',
				'query_var'          => true,
				// 'rewrite'            => true,.
				'capability_type'    => 'post',
				'has_archive'        => true,
				'hierarchical'       => false,
				'menu_position'      => 30,
				'rewrite'            => array(
					'slug'       => 'addify_quote',
					'with_front' => false,
				),
				'supports'           => array( 'title' ),
			);

			register_post_type( 'addify_quote', $args );
		}

		public function afrfq_register_settings() {
			
			add_rewrite_endpoint( 'request-quote', EP_ROOT | EP_PAGES );
			flush_rewrite_rules();
			
			if ( null === get_page_by_path( 'request-a-quote' ) ) {

				$new_page = array(
					'post_status'    => 'publish',
					'post_type'      => 'page',
					'post_author'    => 1,
					'post_name'      => esc_html__( 'request-a-quote', 'addify_rfq' ),
					'post_title'     => esc_html__( 'Request a Quote', 'addify_rfq' ),
					'post_content'   => '[addify-quote-request-page]',
					'post_parent'    => 0,
					'comment_status' => 'closed',
				);

				$page_id = wp_insert_post( $new_page );

				update_option( 'addify_atq_page_id', $page_id );
			} else {
				$page_id = get_page_by_path( 'request-a-quote' );
				update_option( 'addify_atq_page_id', $page_id );
			}

			$quote_fields_obj = new AF_R_F_Q_Quote_Fields();
			$quote_fields_obj->afrfq_migrate_fields_enabled_to_rules();

			if ( empty( get_option( 'afrfq_admin_email' ) ) ) {
				update_option( 'afrfq_admin_email', get_option( 'admin_email' ), true );
			}

			if ( empty( get_option( 'afrfq_emails' ) ) ) {
				// update_option( 'afrfq_emails', $quote_emails, true );
				$this->afrfq_email_default_values();

			}



			if ( empty( get_option( 'afrfq_success_message' ) ) ) {
				update_option( 'afrfq_success_message', 'Your Quote Submitted Successfully.', true );
			}

			if ( empty( get_option( 'afrfq_pro_success_message' ) ) ) {
				update_option( 'afrfq_pro_success_message', 'Product Added to Quote Successfully.', true );
			}

			if ( empty( get_option( 'afrfq_view_button_message' ) ) ) {
				update_option( 'afrfq_view_button_message', 'View Quote', true );
			}

			if ( empty( get_option( 'afrfq_basket_option' ) ) ) {
				update_option( 'afrfq_basket_option', 'dropdown', true );
			}

			if ( empty( get_option( 'afrfq_backrgound_color' ) ) ) {
				update_option( 'afrfq_backrgound_color', '#d6e4f1', true );
			}

			if ( empty( get_option( 'afrfq_backrgound_color' ) ) ) {
				update_option( 'afrfq_backrgound_color', '#000000', true );
			}
			if ( empty( get_option( 'afrfq_table_header_color' ) ) ) {
				update_option( 'afrfq_table_header_color', '#ffffff', true );
			}
			if ( empty( get_option( 'afrfq_submit_button_fg_color' ) ) ) {
				update_option( 'afrfq_submit_button_fg_color', '#ffffff', true );
			}
		}


		public function afrfq_plugin_deactivate() {
			flush_rewrite_rules();
			delete_option( 'afrfq_endpoints_flushed' );
		}


		public function afrfq_email_default_values() {
			$emails = array(
				'af_admin'                   => array(
					'enable'  => '',
					'subject' => 'You’ve received a new quote request – #{quote_id}',
					'heading' => 'New Quote Received',
					'message' => 'Hi,<br><br>
									A new quote request has been submitted on your store.<br>
									Quote ID: {quote_id}<br>
									Customer Name: {user_name}<br><br>
									Please review this quote in your WooCommerce dashboard to take the next steps.<br>
									Thank you,<br><br>',
				),
			
				'af_pending'                 => array(
					'enable'  => '',
					'subject' => 'Your quote request has been received – #{quote_id}',
					'heading' => 'We’ve received your quote request',
					'message' => 'Hi {user_name},<br><br>
									Thank you for your interest in our products.<br>
									We’ve received your quote request (ID: {quote_id}) and our team will review it shortly.<br>
									You’ll be notified once it’s processed.<br><br>
									Best regards,<br><br>',
				),
			
				'af_in_process'              => array(
					'enable'  => '',
					'subject' => 'Your quote #{quote_id} is being reviewed',
					'heading' => 'Quote Under Review',
					'message' => 'Hi {user_name},<br><br>
									Your quote request (ID: {quote_id}) is currently being reviewed by our team.<br>
									We’ll get back to you soon with a personalized offer.<br><br>
									Thank you for your patience!<br><br>',
				),
			
				'af_accepted'                => array(
					'enable'  => '',
					'subject' => 'Your quote #{quote_id} has been accepted',
					'heading' => 'Quote Accepted',
					'message' => 'Hi {user_name},<br><br>
									Good news! Your quote request (ID: {quote_id}) has been accepted.<br>
									You can now proceed to confirm your order from your account dashboard.<br><br>',
				),
			
				'af_admin_conv'              => array(
					'enable'  => '',
					'subject' => 'Quote #{quote_id} converted to an order',
					'heading' => 'Quote Converted to Order',
					'message' => 'Hi Admin,<br><br>
									The quote request #{quote_id} from {user_name} has been successfully converted to an order.<br>
									You can view the order details in your WooCommerce dashboard.<br><br>
									Regards,<br><br>',
				),
			
				'af_converted'               => array(
					'enable'  => '',
					'subject' => 'Your quote #{quote_id} has been converted to an order',
					'heading' => 'Order Created from Your Quote',
					'message' => 'Hi {user_name},<br><br>
									Your quote request (ID: {quote_id}) has been successfully converted into an order.<br>
									You can complete the payment or track the order from your account dashboard.<br><br>',
				),
			
				'af_admin_converted_to_cart' => array(
					'enable'  => '',
					'subject' => 'Quote #{quote_id} converted to cart (Admin)',
					'heading' => 'Quote Converted to Cart',
					'message' => 'Hi Admin,<br><br>
									The quote #{quote_id} has been converted to a cart by {user_name}.<br>
									You can review the details in your WooCommerce dashboard.<br><br>',
				),
			
				'af_converted_to_cart'       => array(
					'enable'  => '',
					'subject' => 'Quote #{quote_id} converted to cart',
					'heading' => 'Quote Converted to Cart',
					'message' => 'Hi {user_name},<br><br>
									Your quote request (ID: {quote_id}) has been converted to a shopping cart.<br>
									You can review the cart details and proceed to checkout using the button below.<br><br>',
				),
			
				'af_declined'                => array(
					'enable'  => '',
					'subject' => 'Your quote #{quote_id} could not be processed',
					'heading' => 'Quote Declined',
					'message' => 'Hi {user_name},<br><br>
									We regret to inform you that your quote request (ID: {quote_id}) cannot be processed at this time due to the unavailability of one or more products.<br>
									You can contact our support team for alternatives or product recommendations.<br><br>
									Thank you for understanding,<br><br>',
				),
			
				'af_cancelled'               => array(
					'enable'  => '',
					'subject' => 'Your quote #{quote_id} has been canceled',
					'heading' => 'Quote Canceled',
					'message' => 'Hi {user_name},<br><br>
									Your quote request (ID: {quote_id}) has been canceled.<br>
									If this was done by mistake or you’d like to request a new quote, please visit our store and submit a new one.<br><br>
									Thank you,<br><br>',
				),
			);
			
			update_option( 'afrfq_emails', $emails );
		}
	}

	new Addify_Request_For_Quote();

}
